# Prospective ticket-19 proof guard corrections

These are separate external copies. The repository, live proof tooling, native state, controllers and running processes were not changed or inspected. `baseline/` contains the exact live-tool file bytes used as the starting point. `manifest.json` records baseline and corrected hashes. `proofguard-corrections.patch` is against that external baseline, which already includes the earlier live-driver improvements; it is not a patch against the older repository scripts alone.

## Native runner

- `boundary()` rejects a dirty current source and a dirty source pin. Stable preexisting dirt can no longer receive a successful boundary record.
- A standalone `expect_editor` step now uses Darwin `proc_pidpath` plus `KERN_PROCARGS2` to observe the foreground group leader's actual executable and exact NUL-separated argv. It retains only argc-selected argv, not the trailing process environment. Byte arrays preserve exact argument bytes alongside display text.
- The executable and kernel executable paths must resolve to the exact expected executable; the expected operand must be one complete argv element after argv[0]. Prefix/suffix paths and shell command text cannot satisfy the guard.
- The runner rechecks executable and terminal foreground group, and verifies that its dashboard handle is still live. Missing, unavailable, inconsistent or non-Darwin identity rejects the guard. This remains a fresh observation, not an atomic process-lifetime promise.

Use the existing plan shape in its own pre-action step:

```json
{"expect_editor":{"executable":"/usr/bin/vim","operand":"/absolute/exact/proof.txt"},"timeout":8,"capture":"verified-editor-before-input"}
```

Put editing keys in subsequent plan steps. The generic runner processes input fields before expectation fields within a step, so do not combine editing input and the ownership assertion in one step. The public helper functions are `parse_darwin_procargs2(payload)`, `darwin_editor_identity(pid)` and `editor_identity_matches(identity, expected)`.

No actual Darwin process API was invoked during this task. A focused actual Vim/Pico run with the versioned copied runner is still required; the pure tests validate parsing and rejection predicates only.

## Recovery verifier

- Reference names are classified using the M2 source-defined roles. Canonical workspace/request UUIDs are required. `refs/rat/archive/<workspace>/<request>-index` and `-prepared` require trees; primary archive and removal references require commits. `refs/rat/creation/<request>` requires a commit. `refs/rat/restore/<workspace>/<request>/<branch>` requires a commit and permits slashes in the branch suffix. Unknown roles fail closed.
- Source pointers: `src/archive.rs:109`, `src/archive_git.rs:275–282` staged-index/prepared-tree references, `src/creation.rs:405` creation base claims, `src/removal_git.rs:577`, and `src/archive_restore.rs:123`. Only static source inspection was used; no live Git reference/state/controller reads were performed.
- The selected-context check requires the same previous selected workspace, managed segment and native conversation, with the selected native ID agreeing with the retained record. Restoring any other known session is no longer accepted as preserving selected context. The separate latest-segment-restoration check remains unchanged.
- An unavailable/malformed pre-checkpoint public context produces `None` (unverified), not success. To qualify selected-context preservation, the final preboot checkpoint needs an available public observation, or a separately specified durable selected-context capture would be needed.
- No coding launch, reboot, sleep or PID-signalling path was added. The existing explicit supervisor-start-after-changed-boot behavior is unchanged.

Changing the verifier hash intentionally invalidates checkpoints made by the older verifier. Capture a fresh final checkpoint with this exact version before the physical reboot gate; do not edit an old checkpoint to make it pass.

## Pure validation

`PYTHONDONTWRITEBYTECODE=1 python3 test_guards.py -v` passes 18 cases. They cover stable dirt, dirty pins, exact executable/operand identity, shell mentions, operand prefix/suffix, missing/inconsistent process evidence, raw-byte/space argv parsing, truncated argv, archive index/prepared trees, creation/primary/removal/restore commit roles, invalid UUID/unknown role, changed selected segment/workspace/native ID, and missing prior public evidence.

`baseline-counterexamples.py` evaluates original source functions or literal AST predicates against pure fixtures. It confirms that each original guard accepted its corresponding counterexample, while the corrected editor and selected-context predicates reject them. The baseline Git response is a pure mocked function; no subprocess runs. Results are in `baseline-counterexamples.json` and `pure-tests.log`.

## Corrected valid-role omission (v2)

The first strict verifier version `434c300c62332186aaabd9eacc65969c27ef72960e9fc2b30516dc83a29f111b` incorrectly rejected two valid source-defined roles: archive prepared-tree references and creation base-claim references. The parent reported an actual cold-verifier RED on these names. That failure must remain failed; this correction is not a reinterpretation of its result.

The exact v1 verifier, tests, notes, manifest, patch, original 16-case pure log and counterexample record are retained unchanged under `previous/434c300c/`. `prepared-creation-v1-red.json` independently shows the v1 helper rejecting both valid shapes through pure fixtures. Source inspection confirmed archive preparation pins `r.tree` at `<archive-reference>-prepared` (`src/archive_git.rs:279–282`) and creation claims pin the committed creation base at `refs/rat/creation/<request>` (`src/creation.rs:395–405` and its corresponding update-ref flow/tests).

V2 adds only those exact canonical-UUID roles. Prepared refs still reject commit objects; creation claims reject trees, invalid UUIDs and extra path components. Primary archive/removal/restore ref constraints stay unchanged. The final pure 18-case run is `pure-tests-v2.log`; the earlier `pure-tests.log` is preserved, not overwritten. A fresh checkpoint using the final verifier hash is still required; no live state/controller/process introspection occurred in this correction.
