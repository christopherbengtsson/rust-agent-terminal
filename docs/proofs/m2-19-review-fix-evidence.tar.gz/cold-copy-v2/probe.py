import hashlib,json,os,pathlib,shutil,socket,subprocess,time,uuid
old=pathlib.Path('/Users/christopherbengtsson/.rat19-proof-a56eee5/state')
root=pathlib.Path.home()/'.rat19-reviewfix-v2'
root.mkdir(mode=0o700,exist_ok=False)
state=root/'state';state.mkdir(mode=0o700)
sha=lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
before={p.name:sha(p) for p in old.iterdir() if p.is_file() and (p.name=='history.sqlite3' or p.suffix=='.transcript')}
for name in before: shutil.copy2(old/name,state/name)
binary=pathlib.Path('/tmp/rat-m2-review-fix/target/debug/agent-terminal').resolve()
log=open(root/'owner.log','wb')
owner=subprocess.Popen([str(binary),'--supervisor',str(state)],stdout=log,stderr=subprocess.STDOUT)
record={'binary':str(binary),'binary_sha256':sha(binary),'source_head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=binary.parents[2]).decode().strip(),'old_input_hashes':before,'copied_names':sorted(before),'fresh_owner_pid':owner.pid,'no_native_launch_request_sent':True,'observations':[]}
sock=None
try:
 end=time.monotonic()+10
 while True:
  try:
   sock=socket.socket(socket.AF_UNIX);sock.settimeout(5);sock.connect(str(state/'supervisor.sock'));break
  except (FileNotFoundError,ConnectionRefusedError):
   sock.close();assert time.monotonic()<end;time.sleep(.02)
 stream=sock.makefile('rwb',buffering=0)
 def read():
  line=stream.readline();assert line;return json.loads(line)
 current=read()
 def request(value):
  stream.write(json.dumps(value).encode()+b'\n');return read()
 while not(current['removal']['ready'] and current['archive']['status']=='Archive operation settled' and all(o['lifecycle']!='Stopped' or not o['reserved'] for o in current['sessions'])):
  assert time.monotonic()<end
  current=request('Screen')
 workspace='803ff645-4dbb-49fc-8fa4-275f108f530a'
 original='0cc0c78c-7a00-4102-b180-ff567c6f02d9'
 native='be6e219c-edbb-4bb2-8ca7-8f79f72879e7'
 known=next(w for w in current['registry']['workspaces'] if w['id']==workspace)
 assert not pathlib.Path(bytes(known['path']).decode()).exists()
 assert workspace in current['registry']['archived']
 assert any(r['workspace']==workspace and r['phase']=='Removed' for r in current['removal']['records'])
 before_sessions=current['sessions']
 record['observations'].append({'stage':'ready','state':current})
 current=request({'ResumeSelected':{'request':str(uuid.uuid4()),'workspace':workspace,'session':original}})
 record['observations'].append({'stage':'removed-refusal','state':current})
 assert 'Workspace folder removed;' in current['error'],current['error']
 assert 'recovery reference' in current['error'] and 'pending' not in current['error']
 assert current['native_conversation']==native
 assert current['session_identity']['session']==original
 assert current['sessions']==before_sessions
 assert current['execution'] is None
 assert all(s['lifecycle']!='Running' for s in current['sessions'])
 record['no_new_segment']=True
 record['same_boot_interrupted_reservation_preserved']=any(s['lifecycle']=='Interrupted' and s['reserved'] for s in current['sessions'])
 assert record['same_boot_interrupted_reservation_preserved']
 # Shutdown preserves the same-boot reservation. No automatic execution is
 # allowed; terminate only the exact supervisor child held by this Popen.
 record['shutdown_reply']=request('Shutdown')
except BaseException as exc:
 record['failure']=repr(exc)
 raise
finally:
 if sock:sock.close()
 if owner.poll() is None:
  record['cleanup']='terminate freshly created supervisor through held Popen; never signal retained PID'
  owner.terminate()
  owner.wait(timeout=10)
 else:record['cleanup']='owner exited'
 log.close()
 record['exit_code']=owner.returncode
 record['original_inputs_unchanged']=before=={name:sha(old/name) for name in before}
 record['matching_processes_after']=[line for line in subprocess.check_output(['ps','-axo','pid=,ppid=,command=']).decode().splitlines() if str(binary) in line and 'ps -axo' not in line]
 (root/'probe.json').write_text(json.dumps(record,indent=2))
 assert record['original_inputs_unchanged']
 print(root)
