import glob,hashlib,json,os,pathlib,subprocess,time
root=pathlib.Path('/tmp/rat-m2-review-fix')
evidence=pathlib.Path('/tmp/rat-review-final-2523e94');evidence.mkdir(exist_ok=False)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def binaries():
 return {str(p.relative_to(root)):sha(p) for p in [root/'target/debug/agent-terminal',*sorted((root/'target/debug/deps').iterdir())] if p.is_file() and os.access(p,os.X_OK)}
manifest={'source':subprocess.check_output(['git','rev-parse','HEAD'],cwd=root).decode().strip(),'source_tree':subprocess.check_output(['git','rev-parse','HEAD:src'],cwd=root).decode().strip(),'clean_before':subprocess.check_output(['git','status','--porcelain'],cwd=root).decode(),'binaries_before':binaries(),'checks':[]}
commands=[
 ('editor-pty',['cargo','+stable','test','--locked','--test','editor','--','--include-ignored','--test-threads=1','--nocapture'],{}),
 ('editor-positions',['cargo','+stable','test','--locked','--bin','agent-terminal','editor::tests','--','--include-ignored','--test-threads=1','--nocapture'],{}),
 ('resume',['cargo','+stable','test','--locked','--test','ownership','resume','--','--test-threads=1','--nocapture'],{}),
 ('loading',['cargo','+stable','test','--locked','--test','ownership','unavailable_archive_receipts_keep_start_frozen_with_loading_guidance','--','--nocapture'],{}),
 ('missing-checkout',['cargo','+stable','test','--locked','--test','ownership','stopped_history_survives_restart_and_missing_checkout_without_launching','--','--nocapture'],{}),
 ('pending-removal',['cargo','+stable','test','--locked','--test','ownership','folder_removal_durable_boundary_blocks_alias_launch_and_restart_never_replays_deletion','--','--nocapture'],{}),
 ('diff',['cargo','+stable','test','--locked','--bin','agent-terminal','working_diff::tests','--','--test-threads=1','--nocapture'],{}),
 ('six-stream',['cargo','+stable','test','--locked','--test','ownership','six_stream_coordination_measurement19','--','--ignored','--test-threads=1','--nocapture'],{'RAT_MEASURE19_DIR':'/tmp/rat-review-measure-2523e94-v1'}),
]
for name,cmd,extra in commands:
 print('Running',name,flush=True);start=time.monotonic()
 with open(evidence/(name+'.log'),'wb') as log: result=subprocess.run(cmd,cwd=root,env={**os.environ,**extra},stdout=log,stderr=subprocess.STDOUT)
 manifest['checks'].append({'name':name,'argv':cmd,'environment':extra,'exit':result.returncode,'seconds':time.monotonic()-start})
 (evidence/'manifest.json').write_text(json.dumps(manifest,indent=2))
 print(name,'exit',result.returncode,'seconds',manifest['checks'][-1]['seconds'],flush=True)
 if result.returncode:break
manifest['binaries_after']=binaries();manifest['clean_after']=subprocess.check_output(['git','status','--porcelain'],cwd=root).decode();manifest['binaries_unchanged']=manifest['binaries_before']==manifest['binaries_after']
(evidence/'manifest.json').write_text(json.dumps(manifest,indent=2))
print('Binaries unchanged',manifest['binaries_unchanged'],flush=True)
