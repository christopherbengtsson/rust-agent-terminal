import os,sys,pty,fcntl,termios,struct,subprocess,time,socket,json,select,hashlib,uuid
from pathlib import Path
kind=sys.argv[1]; root=Path('/tmp/rat08-proof'); binary='/tmp/rat-ticket08/target/debug/agent-terminal'; tag=sys.argv[2] if len(sys.argv)>2 else 'one'; base='/private/tmp/rat08-'+kind+'-'+tag; repo=base+'-checkout'; state=base+'-state'; assert not os.path.exists(repo) and not os.path.exists(state)
subprocess.run(['git','init','-b','main',repo],check=True,capture_output=True)
marker='HISTORY08-'+kind.upper()+'-COMMAND-OUTPUT'
Path(repo+'/proof-output.py').write_text('print('+repr(marker)+', flush=True)\n')
proof={'driver_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'parser_sha256':hashlib.sha256(Path('/private/tmp/rat18-parse').read_bytes()).hexdigest(),'source':subprocess.check_output(['git','-C','/tmp/rat-ticket08','rev-parse','HEAD']).decode().strip(),'binary':binary,'binary_sha256':hashlib.sha256(Path(binary).read_bytes()).hexdigest(),'kind':kind,'repo':repo,'state':state,'snapshots':[]}
canonical=os.path.realpath(subprocess.check_output(['which',kind]).decode().strip());proof['native_binary']=canonical;proof['native_sha256']=hashlib.sha256(Path(canonical).read_bytes()).hexdigest();proof['native_version']=subprocess.check_output([canonical,'--version']).decode().strip()
master,slave=pty.openpty();original=termios.tcgetattr(slave);fcntl.ioctl(slave,termios.TIOCSWINSZ,struct.pack('HHHH',40,160,0,0));raw=bytearray();p=None
name='native-'+kind+'-'+tag
# Only terminal output is retained; no raw input-key stream is recorded.
def wait(t=.3):
 end=time.monotonic()+t
 while time.monotonic()<end:
  if select.select([master],[],[],.03)[0]:
   try:
    b=os.read(master,65536)
    if not b:break
    raw.extend(b);assert len(raw)<=8*1024*1024
   except OSError:break
def send(b):os.write(master,b);wait()
def screen(label='latest'):
 path=root/(name+'-'+label+'.raw');path.write_bytes(raw);subprocess.run(['/private/tmp/rat18-parse',str(path),'40','160'],check=True);return json.loads(path.with_suffix('.cells.json').read_text())['text']
def until(pred,seconds=50):
 end=time.monotonic()+seconds
 while time.monotonic()<end:
  wait(.2);text=screen()
  if pred(text):return text
 raise RuntimeError('timeout: '+screen())
def connect():
 end=time.monotonic()+8
 while time.monotonic()<end:
  s=socket.socket(socket.AF_UNIX);s.settimeout(3)
  try:
   s.connect(state+'/supervisor.sock');f=s.makefile('rb');d=json.loads(f.readline(4194305))
   if not d.get('control_denied'):return s,f,d
  except (OSError,ValueError):pass
  s.close();time.sleep(.1)
 raise RuntimeError('no controller')
def request(s,f,value):s.sendall(json.dumps(value).encode()+b'\n');return json.loads(f.readline(4194305))
def snapshot(label):
 screen(label);proof['snapshots'].append(label)
def launch():
 global p,raw
 for attempt in range(5):
  raw=bytearray();p=subprocess.Popen([binary,repo,'--state-dir',state],stdin=slave,stdout=slave,stderr=slave,start_new_session=True);wait(1)
  if 'Another dashboard controls' not in screen():return
  send(b'd');wait(.5);p.wait(timeout=4);wait(.5)
 raise RuntimeError('controller did not release after explicit disconnect')
try:
 launch();until(lambda t:'Discovery complete' in t);send(b'a');until(lambda t:'Adopted:' in t)
 send(b'C' if kind=='claude' else b'X');until(lambda t:'First prompt' in t)
 prompt='Say exactly HISTORY08-'+kind.upper()+'-ANSWER then ask whether I want the bounded output check. Do not run tools or change files.'
 proof['initial_prompt']=prompt;send(b'\x1b[200~'+prompt.encode()+b'\x1b[201~');send(b'\r')
 if kind=='claude':
  until(lambda t:'Accessing workspace' in t);snapshot('trust');send(b'\x1b[B');send(b'\r')
 else:
  until(lambda t:'Trust this folder?' in t);snapshot('trust');send(b'\r')
  text=until(lambda t:'Hooks need review' in t or 'HISTORY08-CODEX-ANSWER' in t)
  if 'Hooks need review' in text:snapshot('hooks');send(b'\x1b[B');send(b'\r')
 until(lambda t:t.count('HISTORY08-'+kind.upper()+'-ANSWER')>=2 and 'output check' in t,80);wait(2);snapshot('first-answer')
 if kind=='claude':
  for _ in range(4):
   if 'manual mode on' in screen():break
   send(b'\x1b[Z')
  assert 'manual mode on' in screen(),screen()
 follow='Yes. Run exactly python3 proof-output.py once in this temporary checkout, then report its exact output. This script only prints a harmless qualification marker. Do not run other commands or change files.'
 if kind=='codex':follow+=' Use require_escalated permission and a justification so I can approve it once.'
 proof['explicit_followup_prompt']=follow;send(b'\x1b[200~'+follow.encode()+b'\x1b[201~');send(b'\r')
 until(lambda t:('Do you want to proceed?' in t if kind=='claude' else 'Would you like to run the following command?' in t),80);snapshot('approval');send(b'\r')
 until(lambda t:marker in t,80);wait(3);snapshot('command-output')
 send(b'\x1d');send(b'd');p.wait(timeout=8);proof['terminal_restored_detach']=termios.tcgetattr(slave)==original
 s,f,current=connect();proof['after_output']=current;native_pid=current['execution']['pid'];proof['native_pid']=native_pid
 proof['native_ps']=subprocess.check_output(['ps','-p',str(native_pid),'-o','pid,ppid,pgid,command']).decode();proof['native_cwd']=subprocess.check_output(['lsof','-a','-p',str(native_pid),'-d','cwd','-Fn']).decode()
 stopped=request(s,f,'Stop');end=time.monotonic()+20
 while time.monotonic()<end:
  if stopped['lifecycle']=='Stopped' and not stopped['metadata_pending'] and stopped['capture_pending_bytes']==0:break
  time.sleep(.1);stopped=request(s,f,'Screen')
 else:raise RuntimeError('stop did not settle '+str(stopped))
 proof['stopped']=stopped;assert stopped['execution'] is None
 assert not subprocess.run(['ps','-p',str(native_pid),'-o','pid='],capture_output=True,text=True).stdout.strip();proof['owned_processes_gone']=True
 pages=[];offset=0
 while True:
  reply=request(s,f,{'History':{'index':0,'offset':offset}});end=time.monotonic()+15
  while time.monotonic()<end:
   page=reply.get('history')
   if page and page['offset']==offset and not page.get('projection_preparing') and page.get('readable'):break
   time.sleep(.05);reply=request(s,f,'Screen')
  else:raise RuntimeError('readable page timeout '+str(reply))
  pages.append(page)
  if page.get('next') is None:break
  offset=page['next']
 proof['readable_pages']=pages;text=''.join(page['readable']['text'] for page in pages)
 assert marker in text,('no readable command output marker',text);assert 'HISTORY08-'+kind.upper()+'-ANSWER' in text;assert 'proof-output.py' in text
 proof['output_marker']=marker;proof['raw_committed']=stopped['durable_bytes']
 shutdown=request(s,f,'Shutdown');end=time.monotonic()+12
 while not shutdown['stopped'] and time.monotonic()<end:time.sleep(.1);shutdown=request(s,f,'Screen')
 assert shutdown['stopped'];proof['shutdown']=shutdown;f.close();s.close();wait(.3)
 launch();until(lambda t:'Stopped' in t);send(b'h');until(lambda t:'History' in t and 'Preparing readable' not in t);snapshot('readable-view');send(b'v');wait(.3);snapshot('raw-view');assert 'escaped raw' in screen();send(b'd');p.wait(timeout=8)
 s,f,restored=connect();proof['restored']=restored;assert restored['execution'] is None and restored['lifecycle']=='Stopped'
 shutdown=request(s,f,'Shutdown');end=time.monotonic()+12
 while not shutdown['stopped'] and time.monotonic()<end:time.sleep(.1);shutdown=request(s,f,'Screen')
 assert shutdown['stopped'];f.close();s.close();proof['passed']=True
except BaseException as e:
 proof['passed']=False;proof['error']=repr(e)
 try:snapshot('failure')
 except:pass
 try:
  if p and p.poll() is None:send(b'\x1b');send(b'\x1d');send(b'd');p.wait(timeout=4)
  s,f,d=connect();proof['failure_cleanup_initial']=d;d=request(s,f,'Stop');end=time.monotonic()+15
  while time.monotonic()<end and d.get('execution') is not None:time.sleep(.1);d=request(s,f,'Screen')
  proof['failure_cleanup']=d;request(s,f,'Shutdown');f.close();s.close()
 except BaseException as cleanup:proof['cleanup_error']=repr(cleanup)
finally:
 (root/(name+'.json')).write_text(json.dumps(proof,ensure_ascii=False,indent=2));os.close(slave);print(json.dumps({'passed':proof['passed'],'error':proof.get('error'),'file':str(root/(name+'.json'))}))
if not proof['passed']:sys.exit(1)
