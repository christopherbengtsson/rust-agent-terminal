import AppKit
import Foundation
let input = CommandLine.arguments[1]
let output = CommandLine.arguments[2]
let object = try JSONSerialization.jsonObject(with: Data(contentsOf: URL(fileURLWithPath: input))) as! [String: Any]
let cols = object["cols"] as! Int, rows = object["rows"] as! Int
let width = cols * 8, height = rows * 17
let image = NSImage(size: NSSize(width: width, height: height))
image.lockFocus()
NSColor(srgbRed: 12/255, green: 17/255, blue: 24/255, alpha: 1).setFill()
NSRect(x: 0, y: 0, width: width, height: height).fill()
let font = NSFont(name: "Menlo", size: 13)!
for cell in object["cells"] as! [[String: Any]] {
    let row = cell["row"] as! Int, col = cell["col"] as! Int
    let text = cell["text"] as! String
    (text as NSString).draw(at: NSPoint(x: col * 8, y: height - (row + 1) * 17), withAttributes: [.font: font, .foregroundColor: NSColor.lightGray])
}
image.unlockFocus()
let representation = NSBitmapImageRep(data: image.tiffRepresentation!)!
try representation.representation(using: .png, properties: [:])!.write(to: URL(fileURLWithPath: output))
