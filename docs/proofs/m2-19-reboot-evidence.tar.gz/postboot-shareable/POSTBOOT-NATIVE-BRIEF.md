# Actual postboot native recall and cleanup passed

The user-performed real reboot was followed by owner-only restore with zero native starts. This final phase used frozen source `59fed09a8c13505b68d93dd10e5612419a3d08d5` and product SHA-256 `b50530e0e859eb23fd7c61d4442d5fc8dd47c11aaffe39615897be76df460faf` on actual macOS, through proof-only PATH Codex 0.167.0 and Claude Code 2.1.318. No build or repository edit occurred.

| Tool | Exact selected previous managed segment | New managed segment | Original native conversation |
| --- | --- | --- | --- |
| Codex 0.167.0 | `dedec21c-e0ad-4b70-a862-29d6d9ea2fa0` | `19170340-9663-4c87-a2ed-3946ddd54a12` | `01a1b3e1-41ae-74e0-952b-8af0aaeb7a84` |
| Claude Code 2.1.318 | `1e66e7de-3d06-47d7-935c-395d2d2566a4` | `2769e9e3-c70d-4b76-b838-9a5a79677add` | `dcfb6eda-f2a9-41fc-ad34-333ba1067577` |

Each exact historical segment/native UUID was visibly verified in the filtered retained-conversation browser before explicit Resume. No initial prompt was supplied by the launch. The new prompt excluded the old marker and forbade tools and file access. Fresh replies were `POSTBOOT_RECALL: M2_19_AMBER_CODEX_RECOVERED` and `POSTBOOT_RECALL: M2_19_VIOLET_CLAUDE`. Both had current-turn Completed evidence, bounded to 30 seconds; silence and later Unknown are not completion proof. Codex invocation-local hooks were reviewed/trusted through its native Hooks UI. No global permission or authentication change occurred.

Fresh Darwin executable, exact raw native argv, process start and canonical cwd checks passed for each native leader. The actual current owner was freshly authenticated using Unix LOCAL_PEERPID and its exact canonical executable/argv/start. Its current ancestry contained the expected native trees. Complete raw native argv remains private because Codex hook arguments contain an invocation-local callback token. The shareable summary retains resume operands, executable, identity and full private argv hash, excluding that token.

New boot did not automatically clear Interrupted reservations. Existing explicit dashboard `u` reconciled Amber and Violet before their resumes; the same control later released prior Cobalt's reservation without starting it. Cobalt remains historically Interrupted, now unreserved. No saved PID was signalled and no database reservation was manually cleared.

Both resumed sessions were explicitly Stopped through product controls. Capture, metadata and registry settled; authenticated ordinary Shutdown then confirmed stopped. Every process in the freshly attributed live owner/native ancestry disappeared. Supervisor and native-status endpoints were absent. The final cold snapshot exactly preserves preboot code/index/untracked/ignored witnesses and typed recovery refs, all old identity bindings and committed transcript prefixes, and adds exactly the two expected new managed segments and workspace bindings. Removed AmberClaude, archived VioletCodex and stopped CobaltCodex remain preserved.

The outer PTY driver's post-exit termios observation returned ENOTTY (`terminal_restored=null`); this phase makes no terminal-restoration claim. The first summary-only check incorrectly demanded complete membership equality despite the two intended new segments; that failed assertion is retained privately and corrected by checking every old binding plus exactly the two expected additions. No native runtime attempt failed or was rerun.

Only `postboot-shareable/` and the paths in its manifest are curated for publication. Raw state, IPC authentication, provider profiles, full host process inventory, and native raw argv remain private. The root agent owns repository documentation and tracker acceptance.
