import os,sys,pty,fcntl,termios,struct,subprocess,time,socket,json,select,signal
kind,action=sys.argv[1:3];label=sys.argv[4] if len(sys.argv)>4 else action; base='/private/tmp/rat18';repo=base+'-'+kind+'-checkout';state=base+'-'+kind+'-state';out='/private/tmp/rat-ticket-18/docs/proofs/screens';os.makedirs(out,exist_ok=True)
if action=='launch':subprocess.run(['git','init','-b','main',repo],check=True,stdout=subprocess.DEVNULL)
tools=base+'-tools';os.makedirs(tools,exist_ok=True)
for tool,path in [('claude','/Users/christopherbengtsson/.local/share/claude/versions/2.1.318'),('codex','/Users/christopherbengtsson/.codex/packages/standalone/releases/0.167.0-aarch64-apple-darwin/bin/codex')]:
 if not os.path.lexists(tools+'/'+tool):os.symlink(path,tools+'/'+tool)
master,slave=pty.openpty();original=termios.tcgetattr(slave);fcntl.ioctl(slave,termios.TIOCSWINSZ,struct.pack('HHHH',40,160,0,0));env=dict(os.environ,PATH=tools+':'+os.environ['PATH']);p=subprocess.Popen(['/private/tmp/rat-ticket-18/target/debug/agent-terminal',repo,'--state-dir',state],stdin=slave,stdout=slave,stderr=slave,start_new_session=True,env=env);raw=bytearray();limit=8*1024*1024
frames=[];stop_evidence=None;crash_evidence=None
def wait(t=.5):
 end=time.monotonic()+t
 while time.monotonic()<end:
  if select.select([master],[],[],.03)[0]:
   try:
    b=os.read(master,65536);raw.extend(b)
    if len(raw)>limit:raise RuntimeError('outer capture limit')
   except OSError:break
def send(b):os.write(master,b);wait()
def capture(label,rows=40,cols=160):
 path=out+'/18-'+kind+'-'+label+'.raw';open(path,'wb').write(raw);frames.append({'path':path,'rows':rows,'cols':cols})
def resize(rows,cols):fcntl.ioctl(master,termios.TIOCSWINSZ,struct.pack('HHHH',rows,cols,0,0));os.kill(p.pid,signal.SIGWINCH);wait(1)
wait(2)
if action=='launch':
 capture('discovery');send(b'a');send(b'c' if kind=='claude' else b'x');wait(7)
elif action=='trust':
 if kind=='claude':send(b'\x1b[B')
 send(b'\r');wait(6)
elif action=='text':send(b'\x1b[200~'+sys.argv[3].encode()+b'\x1b[201~');send(b'\r');wait(18)
elif action=='hex':send(bytes.fromhex(sys.argv[3]));wait(5)
elif action=='interrupt':
 raw.clear();send(b'\x1b[200~Explain Rust ownership and borrowing at great length with twenty detailed sections and code examples. Do not use tools or write files.\x1b[201~');send(b'\r')
 until=time.monotonic()+35
 while time.monotonic()<until and '⏺'.encode() not in raw:wait(.1)
 capture('active-before-interrupt');send(b'\x03');wait(2)
elif action=='resize':
 for rows,cols in [(24,100),(18,60),(40,160),(28,120),(40,160)]:
  resize(rows,cols)
  if rows==18:capture('small-attached',rows,cols)
 send(b'\x1d')
 for rows,cols in [(18,60),(40,160)]:
  resize(rows,cols)
  if rows==18:capture('small-dashboard',rows,cols)
 send(b'\r');wait(1)
elif action=='exit':send(b'/exit');send(b'\r');wait(4)
elif action in ('stop','approve-stop'):
 if action=='approve-stop':send(b'\r');wait(2)
 hb=repo+'/heartbeat.jsonl'
 before=open(hb).readlines() if os.path.exists(hb) else []
 ids=[str(json.loads(before[-1])[k]) for k in ['pid','ppid','pgid']] if before else []
 beforeps=subprocess.check_output(['ps','-p',','.join(ids),'-o','pid,ppid,pgid,lstart,command']).decode() if ids else 'no heartbeat'
 send(b'\x1d');send(b's');wait(3)
 after=open(hb).readlines() if os.path.exists(hb) else []
 afterps=subprocess.run(['ps','-p',','.join(ids),'-o','pid,ppid,pgid,lstart,command'],capture_output=True,text=True).stdout if ids else 'no heartbeat'
 wait(1);stable=len(after)==len(open(hb).readlines()) if os.path.exists(hb) else False
 stop_evidence={'before_count':len(before),'after_count':len(after),'stable_after_stop':stable,'before_ps':beforeps,'after_ps':afterps,'last_before':json.loads(before[-1]) if before else None}

elif action=='new':send(b'c' if kind=='claude' else b'x');wait(7)
elif action=='quit':send(b'\x1d');send(b'q');wait(3)
elif action=='supervisorloss':
 owner=int(sys.argv[3]);actual=subprocess.check_output(['ps','-p',str(owner),'-o','command=']).decode().strip()
 assert actual=='/private/tmp/rat-ticket-18/target/debug/agent-terminal --supervisor '+state,actual
 crash_evidence={'owner':owner,'owner_command':actual};os.kill(owner,signal.SIGKILL);wait(2);send(b'\x1d');capture('supervisor-failure');send(b'd');wait();p.wait(timeout=5)
elif action=='cleanup':send(b'\x1d');send(b'g');wait(1);resize(18,60);capture('small-cleanup',18,60);resize(40,160);capture('normal-cleanup');send(b'\x1b')
elif action=='blocked':send(b'\x1d');send(b'c' if kind=='claude' else b'x');wait(1);capture('replacement-blocked');send(b'h');wait(1)
elif action=='loss':p.kill();p.wait()
capture(label)
if p.poll() is None:send(b'\x1d');capture(label+'-dashboard');send(b'd');wait();p.wait(timeout=8)
restored=termios.tcgetattr(slave)==original;os.close(slave)
result={'action':action,'dashboard_pid':p.pid,'dashboard_exit':p.returncode,'terminal_restored':restored,'crash_evidence':crash_evidence,'stop_evidence':stop_evidence,'captures':frames,'source':'4ec3a8b'}
if action not in ('quit','supervisorloss'):
 for attempt in range(40):
  s=socket.socket(socket.AF_UNIX);s.settimeout(3)
  try:s.connect(state+'/supervisor.sock');f=s.makefile('rb');d=json.loads(f.readline())
  except Exception:s.close();time.sleep(.1);continue
  if not d.get('control_denied'):break
  s.close();time.sleep(.1)
 else:raise RuntimeError('controller unavailable')
 result['observation']=d;s.close()
json.dump(result,open(out+'/18-'+kind+'-'+label+'.json','w'),ensure_ascii=False,indent=2)
print(json.dumps({k:v for k,v in result.items() if k!='observation'}));d=result.get('observation',{});print(json.dumps({k:d.get(k) for k in ['identity','lifecycle','native_conversation','status','execution','error','screen']},ensure_ascii=False))
