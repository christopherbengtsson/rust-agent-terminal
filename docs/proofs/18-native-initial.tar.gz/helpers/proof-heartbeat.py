import os,time,json
from pathlib import Path
p=Path("heartbeat.jsonl")
for n in range(240):
 with p.open("a") as f:
  f.write(json.dumps({"pid":os.getpid(),"ppid":os.getppid(),"pgid":os.getpgrp(),"n":n,"time":time.time()})+"\n");f.flush()
 time.sleep(.5)
