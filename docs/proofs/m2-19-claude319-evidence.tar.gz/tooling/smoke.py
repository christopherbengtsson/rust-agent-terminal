import os,sys,json,subprocess,socket,time
from pathlib import Path
ROOT=Path('/Users/christopherbengtsson/.rat19-smoke319-a56eee5');SOURCE=Path('/Users/christopherbengtsson/.rat19-source-a56eee5')
def observe(label=None):
 end=time.monotonic()+10
 while True:
  sock=socket.socket(socket.AF_UNIX);sock.settimeout(5);reader=None
  try:
   sock.connect(str(ROOT/'state/supervisor.sock'));reader=sock.makefile('rb');g=json.loads(reader.readline())
   if not g.get('control_denied'):
    sock.sendall(b'"Screen"\n');d=json.loads(reader.readline())
    if label:(ROOT/'evidence'/(label+'.json')).write_text(json.dumps(d,indent=2))
    return d
  finally:
   if reader:reader.close()
   sock.close()
  assert time.monotonic()<end;time.sleep(.05)
def drive(label,steps,**options):
 p=ROOT/'plans'/(label+'.json');p.write_text(json.dumps({'geometry':[40,160],'steps':steps,**options},indent=2));env=dict(os.environ,PATH=str(ROOT/'tools')+':'+os.environ['PATH'])
 cmd=[sys.executable,str(ROOT/'tooling/m2-19-native.py'),'drive','--root',str(ROOT),'--source',str(SOURCE),'--binary',str(ROOT/'bin/agent-terminal'),'--pin',str(ROOT/'pin.json'),'--repo',str(ROOT/'checkout'),'--plan',str(p),'--label',label,'--parser',str(ROOT/'tooling/parse-pty')]
 r=subprocess.run(cmd,env=env);result=json.loads((ROOT/'evidence'/label/'result.json').read_text());o=result.get('observation')or{};print(json.dumps({k:o.get(k)for k in ['lifecycle','session_identity','native_conversation','status','error','screen']},ensure_ascii=False,indent=2));return r.returncode,result
if __name__=='__main__':
 label=sys.argv[1];steps=json.load(open(sys.argv[2]));drive(label,steps)
