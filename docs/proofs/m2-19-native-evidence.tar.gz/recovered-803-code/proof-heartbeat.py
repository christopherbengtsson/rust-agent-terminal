import json,os,time
with open('native-heartbeat.jsonl','a', buffering=1) as out:
    for n in range(1200):
        out.write(json.dumps({'n':n,'pid':os.getpid(),'ppid':os.getppid(),'pgid':os.getpgrp(),'mono_ns':time.monotonic_ns()})+'\n')
        time.sleep(.1)
