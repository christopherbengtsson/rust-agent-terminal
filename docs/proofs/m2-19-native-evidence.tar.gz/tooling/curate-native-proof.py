from pathlib import Path
import tarfile,hashlib,json,time
R=Path('/Users/christopherbengtsson/.rat19-proof-a56eee5');A=R/'artifacts';A.mkdir(exist_ok=True);files=[]
for directory in ['evidence','plans','tooling','state','bin','c4-expected','recovered-803-code']:
 for p in (R/directory).rglob('*'):
  if p.is_file() and not p.is_symlink() and '.git' not in p.relative_to(R).parts:files.append(p)
files += [p for p in R.iterdir()if p.is_file()and p.suffix in['.json','.jsonl','.md','.log']]
files=sorted(set(files));manifest={'scope':'only own qualification evidence/tooling/product/state; no external credential/config paths; fixture repos remain durable separately','files':[{'path':str(p.relative_to(R)),'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()}for p in files]};m=A/'native-proof-manifest.json';m.write_text(json.dumps(manifest,indent=2));archive=A/'main-native-proof.tar.gz'
with tarfile.open(archive,'w:gz')as t:
 for p in files+[m]:t.add(p,arcname=str(p.relative_to(R)),recursive=False)
h=hashlib.sha256(archive.read_bytes()).hexdigest();(A/'main-native-proof.sha256').write_text(h+'  '+archive.name+'\n');print(json.dumps({'archive':str(archive),'sha256':h,'bytes':archive.stat().st_size,'files':len(files),'manifest':str(m)},indent=2))
