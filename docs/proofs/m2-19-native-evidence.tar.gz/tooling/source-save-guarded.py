import sys,json,subprocess,hashlib
from pathlib import Path
sys.path.insert(0,'/Users/christopherbengtsson/.rat19-proof-a56eee5/tooling');import operate
r=operate.ROOT;w=r/'amber-claude';target='803ff645-4dbb-49fc-8fa4-275f108f530a';before=operate.observe();assert before['lifecycle']=='Running'
def git(*a):return subprocess.check_output(['git','-C',str(w),*a]).decode().strip()
index=Path(git('rev-parse','--git-path','index'));index=index if index.is_absolute()else w/index;index_hash=hashlib.sha256(index.read_bytes()).hexdigest();staged=git('show',':proof.txt');evidence=[]
for name,config in [('vim',{'executable':'/usr/bin/vim','arguments':['-u','NONE'],'position':'vim'}),('pico',{'executable':'/usr/bin/pico','arguments':[],'position':'plus'})]:
 steps=operate.select('amber-claude')+[operate.text('w'),operate.text('f',1)]+[operate.text('j',.2)for _ in range(3)]+[{'expect_visible':'Workspace '+target,'timeout':5,'wait':.1},{'expect_visible':'M2_19_STAGED_CONTENT','timeout':5,'wait':.1},{'expect_visible':'M2_19_UNSTAGED_CONTENT','timeout':5,'wait':.1,'capture':'ready-selected-proof-before-open'},operate.text('o',.2),{'expect_editor':{'executable':'/usr/bin/'+name,'operand':str(w/'proof.txt')},'timeout':8,'wait':.3,'capture':'actual-live-source-editor-owned'},{'expect_visible':'M2_19_UNSTAGED_CONTENT','timeout':5,'wait':.3}]
 if name=='vim':steps += [operate.key('1b'),operate.text('GoM2_19_VIM_SOURCE_SAVED'),operate.key('1b'),operate.text(':wq'),operate.key('0d',1)]
 else:steps += [operate.key('01'),operate.text('M2_19_PICO_SOURCE_SAVED'),operate.key('0d'),operate.key('0f'),operate.key('0d'),operate.key('18',1)]
 steps += [{'expect_visible':'Returned from LIVE source editing','timeout':5,'wait':.1,'capture':'actual-save-and-return-context'},operate.key('1b',.2)]
 result=operate.drive('guarded-'+name+'-source-save',steps,editor=config,dashboard_color=True)
 o=result['observation'];assert o['working_diff']['workspace']==target;assert o['native_conversation']==before['native_conversation']and o['session_identity']==before['session_identity']and o['execution']==before['execution']
 assert 'M2_19_'+name.upper()+'_SOURCE_SAVED'in(w/'proof.txt').read_text()
 assert git('show',':proof.txt')==staged and hashlib.sha256(index.read_bytes()).hexdigest()==index_hash
 ready=next(s for s in result['steps']if s['action'].get('capture')=='ready-selected-proof-before-open');opened=next(s for s in result['steps']if s['action'].get('capture')=='actual-live-source-editor-owned');returned=next(s for s in result['steps']if s['action'].get('capture')=='actual-save-and-return-context')
 assert ready['foreground_pgrp']==result['dashboard_pid']==returned['foreground_pgrp']and opened['foreground_pgrp']!=result['dashboard_pid'];assert ready['termios_sha256']==returned['termios_sha256']
 evidence.append({'editor':name,'actual_editor':opened['editor_ownership'],'foreground_returned':True,'termios_restored':True,'index_unchanged':True,'runner_sha256':result['runner_sha256']})
(r/'guarded-source-editors.json').write_text(json.dumps({'before':before,'after':operate.observe(),'source':(w/'proof.txt').read_text(),'staged':staged,'index_sha256':index_hash,'results':evidence,'script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest()},indent=2)+'\n')
