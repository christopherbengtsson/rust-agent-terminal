import sys,json,time,subprocess,hashlib
sys.path.insert(0,'/Users/christopherbengtsson/.rat19-proof-a56eee5/tooling');import operate
before=operate.observe();target=next(r['target']for r in before['sessions']if bytes(r.get('checkout')or[]).decode()==str(operate.ROOT/'amber-claude'))
active=operate.drive('approve-foreground-heartbeat-once',operate.select('amber-claude')+[operate.key('0d'),operate.key('0d',1),{'capture':'actual-foreground-heartbeat-active','wait':.2}])['observation']
hb=operate.ROOT/'amber-claude/native-heartbeat.jsonl';deadline=time.monotonic()+5
while not hb.exists()and time.monotonic()<deadline:time.sleep(.02)
assert hb.exists(),'approved foreground child did not start'
lines_before=hb.read_text().splitlines();child=json.loads(lines_before[-1]);ids={str(child[k])for k in ['pid','ppid','pgid']}|{str(active['execution']['pid'])}
ps_before=subprocess.run(['ps','-p',','.join(sorted(ids)),'-o','pid,ppid,pgid,lstart,command'],capture_output=True,text=True).stdout
assert str(child['pid']) in ps_before and len(lines_before)>0
stopped=operate.drive('stop-only-native-foreground-workspace',operate.select('amber-claude')+[operate.text('s',3),{'capture':'scoped-native-stop-result','wait':.3}])['observation']
deadline=time.monotonic()+8
while stopped['metadata_pending'] or stopped['capture_pending_bytes']:
 assert time.monotonic()<deadline,stopped
 time.sleep(.03);stopped=operate.observe()
assert stopped['lifecycle']=='Stopped',stopped
others_before={r['target']:(r['session'],r['lifecycle'],r['checkout'])for r in before['sessions']if r['lifecycle']=='Running'and r['target']!=target};others_after={r['target']:(r['session'],r['lifecycle'],r['checkout'])for r in stopped['sessions']if r['lifecycle']=='Running'}
assert len(others_before)==5 and others_before==others_after
last=hb.read_text();time.sleep(.5);assert hb.read_text()==last,'foreground heartbeat continued after confirmed Stop'
ps_after=subprocess.run(['ps','-p',','.join(sorted(ids)),'-o','pid,ppid,pgid,lstart,command'],capture_output=True,text=True).stdout
assert not any(line.split()and line.split()[0]==str(child['pid'])for line in ps_after.splitlines()[1:]),ps_after
result={'before':before,'active':active,'stopped':stopped,'heartbeat_before_lines':len(lines_before),'heartbeat_after_lines':len(last.splitlines()),'last_heartbeat':json.loads(last.splitlines()[-1]),'stable_after_stop':True,'other_five_unchanged_running':True,'ps_before':ps_before,'ps_after':ps_after,'script_sha256':hashlib.sha256((operate.ROOT/'amber-claude/proof-heartbeat.py').read_bytes()).hexdigest()}
(operate.ROOT/'claude-scoped-stop.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({k:v for k,v in result.items()if k not in ['before','active','stopped']},indent=2))
