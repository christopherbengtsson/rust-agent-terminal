import sys,json,socket,time
from pathlib import Path
R=Path('/Users/christopherbengtsson/.rat19-proof-a56eee5');sys.path.insert(0,str(R/'tooling'));import operate as o
before=o.observe();s=socket.socket(socket.AF_UNIX);s.connect(str(R/'state/supervisor.sock'));f=s.makefile('rb');g=json.loads(f.readline());assert not g['control_denied'];s.sendall(b'"Shutdown"\n');after=json.loads(f.readline());f.close();s.close();time.sleep(3)
(R/('authenticated-owner-close-'+str(time.time_ns())+'.json')).write_text(json.dumps({'before':before,'response':after,'socket_exists_after':(R/'state/supervisor.sock').exists()},indent=2))
