import sys,json,hashlib
from pathlib import Path
sys.path.insert(0,'/Users/christopherbengtsson/.rat19-proof-a56eee5/tooling');import operate
before=operate.observe();rows=[];config={'executable':'/usr/bin/pico','arguments':[],'position':'plus'}
for whole in[False,True]:
 steps=operate.select('amber-claude')+[operate.text('w'),operate.text('f',1)]
 if whole:steps+=[operate.text('w',1)];at=2;marker='M2_19_EARLIER_BRANCH_COMMIT'
 else:at=3;marker='M2_19_STAGED_CONTENT'
 steps += [operate.text('j',.2)for _ in range(at)]+[{'expect_visible':marker,'wait':.1,'timeout':5,'capture':'selected-comparison-ready'},operate.text('e',.2),{'expect_editor':{'executable':'/usr/bin/pico','operand':'comparison.diff'},'wait':.3,'timeout':8},{'expect_visible':'comparison.diff','timeout':5,'wait':.2,'capture':'actual-pico-comparison'},operate.key('03',.1),{'resize':[30,100],'wait':.4,'capture':'pico-inspection-resized'},operate.key('18',1),{'expect_visible':'Returned from inspection','timeout':5,'wait':.1,'capture':'returned-pico-comparison'},{'resize':[40,160],'wait':.5},operate.key('1b',.2)]
 result=operate.drive('pico-integrated-'+('whole'if whole else'working'),steps,editor=config,dashboard_color=True);o=result['observation'];assert o['working_diff']['workspace']=='803ff645-4dbb-49fc-8fa4-275f108f530a';assert o['session_identity']==before['session_identity']and o['execution']==before['execution']and o['native_conversation']==before['native_conversation']
 a=next(s for s in result['steps']if s['action'].get('capture')=='selected-comparison-ready');b=next(s for s in result['steps']if s['action'].get('capture')=='actual-pico-comparison');c=next(s for s in result['steps']if s['action'].get('capture')=='returned-pico-comparison');assert a['foreground_pgrp']==result['dashboard_pid']==c['foreground_pgrp']and b['foreground_pgrp']!=result['dashboard_pid'];assert a['termios_sha256']==c['termios_sha256'];rows.append({'whole':whole,'before_foreground':a['foreground_pgrp'],'editor_foreground':b['foreground_pgrp'],'returned_foreground':c['foreground_pgrp'],'termios_restored':True,'target':o['working_diff']['workspace'],'runner_sha256':result['runner_sha256']})
(operate.ROOT/'pico-integrated-comparisons.json').write_text(json.dumps({'rows':rows,'before':before,'after':operate.observe(),'script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest()},indent=2)+'\n')
