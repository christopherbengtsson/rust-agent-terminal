import sys,json,hashlib
from pathlib import Path
sys.path.insert(0,'/Users/christopherbengtsson/.rat19-proof-a56eee5/tooling');import operate
original=next(row for row in json.loads((operate.ROOT/'six-known-native-identities.json').read_text())['rows']if row['name']=='amber-claude')
assert 'Hooks need review' in operate.observe()['screen']
newer=operate.drive('trust-newer-codex-before-first-turn',operate.select('amber-claude')+[operate.key('0d'),operate.key('1b5b42',.2),operate.key('0d',6),{'capture':'newer-codex-conversation','wait':.2}])['observation']
assert newer['agent']=='Codex CLI' and newer['native_conversation'] and newer['native_conversation']!=original['native_conversation']
assert '• M2_19_NEWER_CODEX_IN_CLAUDE_WORKSPACE' in newer['screen']
exited=operate.drive('native-exit-newer-codex-before-older-selection',operate.select('amber-claude')+[operate.key('0d'),operate.text('/exit',.5),operate.key('0d',3)])['observation']
assert exited['lifecycle']=='Exited',exited
# Scoped B rows are insertion-ordered: failed318, firstsuccessful318, newerCodex.
resumed=operate.drive('keyboard-select-original-successful-claude-id',operate.select('amber-claude')+[operate.text('w'),operate.text('B',1),operate.key('1b5b42',.2),{'expect_visible':original['session_identity']['session'],'timeout':5,'wait':.1,'capture':'selected-original-successful-segment'},operate.text('v',5),{'capture':'native-original-id-resumed','wait':.3}])
o=resumed['observation'];assert o['agent']=='Claude Code' and o['native_conversation']==original['native_conversation'] and o['lifecycle']=='Running',o
assert o['session_identity']['session']not in [original['session_identity']['session'],newer['session_identity']['session']]
assert any('--resume '+original['native_conversation']in p['ps'] and ' -- Reply exactly 'not in p['ps']for p in resumed['processes']),resumed['processes']
recall=operate.drive('recall-original-claude-first-marker',operate.select('amber-claude')+[operate.key('0d'),{'paste':'What exact marker did I ask you to reply with in my first message of this conversation? Reply RECALLED: followed by that marker. Do not use tools or change files.','wait':.2},operate.key('0d',7),{'capture':'fresh-original-conversation-recall','wait':.2}])['observation']
assert 'RECALLED: M2_19_AMBER_CLAUDE' in recall['screen'],recall
result={'original':original,'newer_other_tool':newer,'newer_exited':exited,'resumed':o,'resumed_processes':resumed['processes'],'recall':recall,'first_prompt_not_replayed':True,'original_tool_and_native_id_preserved':True,'script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest()}
(operate.ROOT/'older-original-claude-resume.json').write_text(json.dumps(result,indent=2)+'\n')
