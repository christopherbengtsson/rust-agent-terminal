import sys,json,subprocess,hashlib
from pathlib import Path
sys.path.insert(0,'/Users/christopherbengtsson/.rat19-proof-a56eee5/tooling');import operate
root=operate.ROOT;workspace=root/'amber-claude';target='803ff645-4dbb-49fc-8fa4-275f108f530a';before=operate.observe();evidence=[]
def git(*args):return subprocess.check_output(['git','-C',str(workspace),*args]).decode().strip()
index=Path(git('rev-parse','--git-path','index'));index=index if index.is_absolute()else workspace/index
index_before=hashlib.sha256(index.read_bytes()).hexdigest();staged_before=git('show',':proof.txt')
for name,config,close in [('vim',{'executable':'/usr/bin/vim','arguments':['-u','NONE'],'position':'vim'},'1b3a710d'),('pico',{'executable':'/usr/bin/pico','arguments':[],'position':'plus'},'18')]:
 for whole in [False,True]:
  steps=operate.select('amber-claude')+[operate.text('w'),operate.text('f',1)]
  if whole:steps+=[operate.text('w',1)];selected=2;marker='M2_19_EARLIER_BRANCH_COMMIT'
  else:selected=3;marker='M2_19_STAGED_CONTENT'
  steps += [operate.text('j',.2)for _ in range(selected)]
  steps += [{'expect_visible':marker,'timeout':5,'wait':.1,'capture':'before-editor'},operate.text('e',1),{'expect_visible':'comparison.diff','timeout':5,'wait':.1,'capture':name+('-whole'if whole else'-working')},operate.key('03',.1),{'resize':[30,100],'wait':.5,'capture':'editor-resized'},operate.key(close,1),{'expect_visible':'Returned from inspection','timeout':5,'wait':.1,'capture':'returned-editor-context'},{'resize':[40,160],'wait':.5},operate.key('1b',.2)]
  result=operate.drive('integrated-'+name+('-whole'if whole else'-working'),steps,editor=config,dashboard_color=True)
  observation=result['observation'];assert observation['working_diff']['workspace']==target
  assert observation['session_identity']==before['session_identity']and observation['native_conversation']==before['native_conversation']and observation['execution']==before['execution']
  before_step=next(s for s in result['steps']if s['action'].get('capture')=='before-editor');editor_step=next(s for s in result['steps']if s['action'].get('capture')in[name+'-whole',name+'-working']);returned=next(s for s in result['steps']if s['action'].get('capture')=='returned-editor-context')
  assert before_step['foreground_pgrp']==result['dashboard_pid']==returned['foreground_pgrp']
  assert editor_step['foreground_pgrp']!=result['dashboard_pid']and editor_step['foreground_pgrp']>0
  assert before_step['termios_sha256']==returned['termios_sha256']
  evidence.append({'editor':name,'whole':whole,'runner_sha256':result['runner_sha256'],'dashboard_pid':result['dashboard_pid'],'before_foreground':before_step['foreground_pgrp'],'editor_foreground':editor_step['foreground_pgrp'],'returned_foreground':returned['foreground_pgrp'],'termios_restored':True,'target_workspace':target})
 # Explicitly choose proof.txt in fresh Working, then open that actual live source.
 steps=operate.select('amber-claude')+[operate.text('w'),operate.text('f',1)]+[operate.text('j',.2)for _ in range(3)]+[operate.text('o',1),{'expect_visible':'M2_19_UNSTAGED_CONTENT','timeout':5,'wait':.1,'capture':'live-source-before-save'}]
 if name=='vim':steps += [operate.key('1b'),operate.text('GoM2_19_VIM_SOURCE_SAVED'),operate.key('1b'),operate.text(':wq'),operate.key('0d',1)]
 else:steps += [operate.key('01'),operate.text('M2_19_PICO_SOURCE_SAVED'),operate.key('0d'),operate.key('0f'),operate.key('0d'),operate.key('18',1)]
 steps += [{'expect_visible':'Returned from LIVE source editing','timeout':5,'wait':.1,'capture':'live-source-saved-and-returned'},operate.key('1b',.2)]
 result=operate.drive('integrated-'+name+'-live-source-save',steps,editor=config,dashboard_color=True)
 assert ('M2_19_'+name.upper()+'_SOURCE_SAVED')in(workspace/'proof.txt').read_text()
 assert result['observation']['native_conversation']==before['native_conversation']and result['observation']['session_identity']==before['session_identity']
 assert git('show',':proof.txt')==staged_before and hashlib.sha256(index.read_bytes()).hexdigest()==index_before
 evidence.append({'editor':name,'live_source':str(workspace/'proof.txt'),'marker_saved':True,'staged_index_unchanged':True,'runner_sha256':result['runner_sha256']})
(root/'integrated-editor-assertions.json').write_text(json.dumps({'results':evidence,'source_content':(workspace/'proof.txt').read_text(),'staged_content':staged_before,'staged_index_sha256':index_before,'native_before':before,'native_after':operate.observe(),'script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest()},indent=2)+'\n')
