import argparse,json,subprocess,sys,time,socket,os
from pathlib import Path
ROOT=Path('/Users/christopherbengtsson/.rat19-proof-a56eee5');SOURCE=Path('/Users/christopherbengtsson/.rat19-source-a56eee5')
def observe():
 s=socket.socket(socket.AF_UNIX);s.settimeout(5);s.connect(str(ROOT/'state/supervisor.sock'));f=s.makefile('rb');d=json.loads(f.readline());assert not d['control_denied'],d
 s.sendall(b'"Screen"\n');d=json.loads(f.readline());f.close();s.close();return d
def key(value,wait=.4):return {'hex':value,'wait':wait}
def text(value,wait=.3):return {'text':value,'wait':wait}
def select(name,archived=False):
 d=observe();rows=[w for w in d['registry']['workspaces'] if archived or w['id'] not in d['registry']['archived']];wanted=next(w for w in rows if bytes(w.get('path')or[]).decode()==str(ROOT/name));index=next(i for i,w in enumerate(rows)if w['id']==wanted['id']);steps=[text('w')]
 if archived:steps+=[text('z')]
 return steps+[text('k'*(len(rows)+1)),text('j'*index),key('0d',1),key('1d',.3)]
def drive(label,steps,**options):
 name=str(time.time_ns())+'-'+label;plan={'geometry':[40,160],'steps':steps,**options};path=ROOT/'plans'/(name+'.json');path.write_text(json.dumps(plan,indent=2)+'\n')
 cmd=[sys.executable,str(ROOT/'tooling/m2-19-native.py'),'drive','--root',str(ROOT),'--source',str(SOURCE),'--binary',str(ROOT/'bin/agent-terminal'),'--pin',str(ROOT/'pin.json'),'--repo',str(ROOT/'amber'),'--plan',str(path),'--label',name,'--parser',str(ROOT/'tooling/parse-pty')]
 subprocess.run(cmd,check=True);d=json.loads((ROOT/'evidence'/name/'result.json').read_text());o=d.get('observation')or{};print(json.dumps({'label':name,**{k:o.get(k)for k in ['lifecycle','session_identity','native_conversation','status','error','screen']}},ensure_ascii=False,indent=2));return d
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('workspace');p.add_argument('label');p.add_argument('steps',help='JSON steps after selectingworkspace');p.add_argument('--attach',action='store_true');p.add_argument('--archived',action='store_true');p.add_argument('--ending',default='detach');a=p.parse_args();steps=select(a.workspace,a.archived)
 if a.attach:steps+=[key('0d',.5)]
 drive(a.label,steps+json.loads(a.steps),ending=a.ending)
