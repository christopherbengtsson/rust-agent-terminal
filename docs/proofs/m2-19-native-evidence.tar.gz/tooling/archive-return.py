import sys,json,re,subprocess,hashlib
from pathlib import Path
sys.path.insert(0,'/Users/christopherbengtsson/.rat19-proof-a56eee5/tooling');import operate
r=operate.ROOT;w=r/'amber-claude';wid='803ff645-4dbb-49fc-8fa4-275f108f530a';branch='refs/heads/workspace/m2-19-amber-claude'
def git(*a):return subprocess.check_output(['git','-C',str(w),*a],stderr=subprocess.STDOUT).decode().strip()
before=operate.observe();assert before['registry']['selected']==wid;known=next(x for x in before['registry']['workspaces']if x['id']==wid);assert bytes(known['path']).decode()==str(w);head=git('rev-parse','HEAD');source=(w/'proof.txt').read_bytes();staged=git('show',':proof.txt');assert head=='449f17ad46909dc8f356679e94a23337bcdcc3c1'
steps=operate.select('amber-claude')+[operate.text('K',.5),{'expect_visible':'Target: '+branch,'timeout':5,'wait':.1,'capture':'archive-exact-owned-branch-preview'},operate.key('0d',5),{'capture':'saved-checkpoint-and-branch-cleanup','wait':.3}]
result=operate.drive('archive-save-owned-branch-cleanup',steps,dashboard_color=True);o=result['observation'];record=next(x for x in reversed(o['archive']['records'])if x['workspace']==wid)
assert record['phase']=='Archived'and record['branch_phase']=='Cleaned',record
assert record['before']==head and bytes(record['checkout']['root']).decode()==str(w);assert record['reference']=='refs/rat/archive/'+wid+'/'+record['request']
preview=next(s for s in result['steps']if s['action'].get('capture')=='archive-exact-owned-branch-preview');frame_path=Path(preview['cell_capture']);text=json.loads(frame_path.read_text())['text'];request=re.search(r'Request ([0-9a-f-]{36})',text).group(1);assert request==record['request']
assert git('rev-parse',record['reference'])==record['saved'];assert git('show',record['reference']+':proof.txt').encode()+b'\n'==source
assert git('show',record['reference']+'-index:proof.txt')==staged
assert subprocess.run(['git','-C',str(w),'show-ref','--verify',branch],capture_output=True).returncode!=0
assert (w/'ignored-native.txt').read_text()=='M2_19_IGNORED_NOT_IN_ARCHIVE\n'and any(bytes(p)==b'ignored-native.txt'for p in record['excluded']);assert subprocess.run(['git','-C',str(w),'cat-file','-e',record['reference']+':ignored-native.txt'],capture_output=True).returncode!=0
assert o['lifecycle']=='Stopped'and wid in o['registry']['archived']
# The exact saved revision/reference is visible before Return confirms it.
returned=operate.drive('return-exact-archived-checkpoint',operate.select('amber-claude',True)+[operate.text('K',.5),{'expect_visible':record['saved'],'timeout':5,'wait':.1},{'expect_visible':record['reference'],'timeout':5,'wait':.1,'capture':'return-frozen-head-ref-preview'},operate.key('0d',4),{'capture':'returned-branch-coding-still-stopped','wait':.2}],dashboard_color=True)['observation']
rr=next(x for x in reversed(returned['archive']['records'])if x['request']==record['request']);assert rr['branch_phase']=='Restored'and wid not in returned['registry']['archived'];assert returned['lifecycle']=='Stopped';assert git('symbolic-ref','HEAD')==branch and git('rev-parse','HEAD')==record['saved'];assert (w/'proof.txt').read_bytes()==source
(r/'archive-return-assertions.json').write_text(json.dumps({'before':before,'archive':record,'archive_observation':o,'return_record':rr,'return_observation':returned,'expected_source_sha256':hashlib.sha256(source).hexdigest(),'staged_recovery_preserved':True,'ignored_file_excluded_and_retained':True,'archive_branch_deleted_then_restored':True,'script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest()},indent=2)+'\n')
