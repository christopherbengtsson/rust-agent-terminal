from pathlib import Path
import json,re,hashlib,time
r=Path('/Users/christopherbengtsson/.rat19-proof-a56eee5')
def case(label):
 p=max((r/'evidence').glob('*-'+label+'/result.json'),key=lambda p:p.stat().st_mtime);d=json.loads(p.read_text());assert d['boundary_stable'] and not d['failure'];return p,d
original=next(row for row in json.loads((r/'six-known-native-identities.json').read_text())['rows']if row['name']=='amber-claude')
newer_path,newer=case('trust-newer-codex-before-first-turn');exit_path,exited=case('native-exit-newer-codex-before-older-selection');resume_path,resumed=case('keyboard-select-original-successful-claude-id');recall_path,recall=case('recall-original-claude-first-marker')
o=resumed['observation'];n=newer['observation'];a=recall['observation'];assert n['agent']=='Codex CLI' and n['native_conversation']!=original['native_conversation'];assert exited['observation']['lifecycle']=='Exited'
assert o['agent']=='Claude Code'and o['native_conversation']==original['native_conversation']and o['lifecycle']=='Running'
assert o['session_identity']['session']not in[original['session_identity']['session'],n['session_identity']['session']]
assert any('--resume '+original['native_conversation']in p['ps']and' -- Reply exactly 'not in p['ps']for p in resumed['processes'])
assert re.search(r'RECALLED:\s*M2_19_AMBER_CLAUDE\b',a['screen'])
result={'original':original,'newer_other_tool':n,'newer_exited':exited['observation'],'resumed':o,'resumed_processes':resumed['processes'],'recall':a,'first_prompt_not_replayed':True,'original_tool_and_native_id_preserved':True,'actual_case_artifacts':[str(p)for p in[newer_path,exit_path,resume_path,recall_path]],'literal_assertion_failure':'initial driver demanded an unspecified space after RECALLED:, actual answer RECALLED:M2_19_AMBER_CLAUDE is the exact original marker; failed log/script retained','recall_status_scope':'Native ID and genuine recall validated; resumed screen status Unknown is not a fresh semantic-label qualification','validator_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'validated_ns':time.time_ns()}
(r/'older-original-claude-resume.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({'original':original['native_conversation'],'newer_tool':n['agent'],'resumed_agent':o['agent'],'fresh_managed_segment':o['session_identity']['session'],'genuine_recall':True,'resumed_status':a['status']},indent=2))
