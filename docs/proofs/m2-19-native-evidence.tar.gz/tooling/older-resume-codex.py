import sys,json,re,hashlib
from pathlib import Path
sys.path.insert(0,'/Users/christopherbengtsson/.rat19-proof-a56eee5/tooling');import operate
original=next(row for row in json.loads((operate.ROOT/'six-known-native-identities.json').read_text())['rows']if row['name']=='violet-codex')
newer=operate.observe();assert newer['agent']=='Claude Code' and '⏺ M2_19_NEWER_CLAUDE_IN_CODEX_WORKSPACE'in newer['screen']
exited=operate.drive('native-exit-newer-claude-before-codex-selection',operate.select('violet-codex')+[operate.key('0d'),operate.text('/exit',.5),operate.key('0d',3)])['observation']
assert exited['lifecycle']=='Exited',exited
resumed=operate.drive('keyboard-select-original-codex-id',operate.select('violet-codex')+[operate.text('w'),operate.text('B',1),{'expect_visible':original['session_identity']['session'],'timeout':5,'wait':.1,'capture':'selected-original-codex-segment'},operate.text('v',4),{'capture':'original-codex-resume-before-hooks','wait':.2}]);o=resumed['observation']
assert o['agent']=='Codex CLI'and o['native_conversation']==original['native_conversation']and o['lifecycle']=='Running',o
assert o['session_identity']['session']not in[original['session_identity']['session'],newer['session_identity']['session']]
assert any('resume '+original['native_conversation']in p['ps']and' -- Reply exactly 'not in p['ps']for p in resumed['processes']),resumed['processes']
if 'Hooks need review'in o['screen']:
 o=operate.drive('trust-original-codex-resume-hooks-before-prompt',operate.select('violet-codex')+[operate.key('0d'),operate.key('1b5b42',.2),operate.key('0d',4),{'capture':'original-codex-after-native-hook-trust','wait':.2}])['observation']
recall=operate.drive('recall-original-codex-first-marker',operate.select('violet-codex')+[operate.key('0d'),{'paste':'What exact marker did I ask you to reply with in my first message of this conversation? Reply RECALLED: followed by that marker. Do not use tools or change files.','wait':.2},operate.key('0d',7),{'capture':'fresh-original-codex-recall','wait':.2}])['observation']
assert re.search(r'RECALLED:\s*M2_19_VIOLET_CODEX\b',recall['screen']),recall
result={'original':original,'newer_other_tool':newer,'newer_exited':exited,'resumed':o,'resumed_processes':resumed['processes'],'recall':recall,'first_prompt_not_replayed':True,'original_tool_and_native_id_preserved':True,'script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest()}
(operate.ROOT/'older-original-codex-resume.json').write_text(json.dumps(result,indent=2)+'\n')
