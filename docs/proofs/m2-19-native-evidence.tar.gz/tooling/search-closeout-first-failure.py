import sys,json
from pathlib import Path
R=Path('/Users/christopherbengtsson/.rat19-proof-a56eee5');sys.path.insert(0,str(R/'tooling'));import operate as o
before=o.observe();(R/'search-before.json').write_text(json.dumps(before,indent=2))
a=o.drive('find-removed-workspace',[o.text('/'),o.text('m2-19-amber-claude'),o.key('0d',1),{'expect_visible':'Enter reads','timeout':10},{'capture':'find-removed-result'},o.key('1b',.2)],ending='detach',dashboard_color=True)
b=o.drive('retained-history-after-removal',[o.text('S'),o.text('M2_19_AMBER_CLAUDE'),o.key('0d',1),{'expect_visible':'Enter reads','timeout':10},{'capture':'retained-match'},o.key('0d',1),{'expect_visible':'Committed passage','timeout':10},{'expect_visible':'M2_19_AMBER_CLAUDE','timeout':10},{'capture':'retained-passage'},o.key('1b',.2),o.key('1b',.2)],ending='detach',dashboard_color=True)
(R/'retained-search-closeout.json').write_text(json.dumps({'find':a,'history':b,'after':o.observe()},indent=2))
