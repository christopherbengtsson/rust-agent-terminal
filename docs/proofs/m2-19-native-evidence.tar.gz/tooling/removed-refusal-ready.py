import sys,json
from pathlib import Path
R=Path('/Users/christopherbengtsson/.rat19-proof-a56eee5');sys.path.insert(0,str(R/'tooling'));import operate as o
a=o.drive('removed-checkout-ready-selected-original-refusal',o.select('amber-claude',True)+[o.text('w'),o.text('B'),o.key('0d',1),{'expect_visible':'Enter reads','timeout':10},o.key('1b5b42'),o.text('v',1),{'capture':'removed-original-refusal'}],ending='loss',dashboard_color=True)
(R/'removed-checkout-ready-refusal.json').write_text(json.dumps(a,indent=2))
