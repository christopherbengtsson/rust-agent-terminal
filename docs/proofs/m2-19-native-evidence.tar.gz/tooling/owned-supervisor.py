import subprocess,sys,json,time,socket,hashlib,os
from pathlib import Path
R=Path('/Users/christopherbengtsson/.rat19-proof-a56eee5');B=R/'bin/agent-terminal';S=R/'state';assert hashlib.sha256(B.read_bytes()).hexdigest()=='89382b1a23124461fbec2bd0944e4b012cfb8d7f056990119a6a02a777569154'
child=None

def observe(request='Screen'):
 end=time.monotonic()+10
 while True:
  s=socket.socket(socket.AF_UNIX);s.settimeout(3);f=None
  try:
   s.connect(str(S/'supervisor.sock'));f=s.makefile('rb');d=json.loads(f.readline())
   if not d['control_denied']:
    s.sendall(json.dumps(request).encode()+b'\n');return json.loads(f.readline())
  except (OSError,ValueError):
   if time.monotonic()>=end:raise
  finally:
   if f:f.close()
   s.close()
  assert time.monotonic()<end
  time.sleep(.05)

def start():
 global child
 assert child is None or child.poll()is not None
 stamp=str(time.time_ns());log=R/('owned-supervisor-'+stamp+'.log')
 with log.open('xb')as f:child=subprocess.Popen([str(B),'--supervisor',str(S)],stdout=f,stderr=subprocess.STDOUT,start_new_session=True)
 d=observe();result={'action':'explicit-owner-start','live_child_pid':child.pid,'argv':[str(B),'--supervisor',str(S)],'log':str(log),'observation':d,'running_coding_count':sum(r['lifecycle']=='Running'for r in d['sessions'])}
 (R/('owner-start-'+stamp+'.json')).write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({k:v for k,v in result.items()if k!='observation'}),flush=True)
start()
for line in sys.stdin:
 command=json.loads(line)
 if command=='status':
  d=observe();print(json.dumps({'child_live':child.poll()is None,'running':sum(r['lifecycle']=='Running'for r in d['sessions']),'selected':d.get('session_identity')}),flush=True)
 elif command=='crash':
  assert child.poll()is None,'live owned child already exited'
  d=observe();pid=child.pid;child.kill();child.wait(timeout=10)
  result={'action':'SIGKILL-to-current-live-Popen-child','pid_live_handle':pid,'exit':child.returncode,'before':d,'no_saved_pid_signalled':True};path=R/('owned-supervisor-crash-'+str(time.time_ns())+'.json');path.write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({'crashed':pid,'exit':child.returncode,'evidence':str(path)}),flush=True)
 elif command=='restart':start()
 elif command=='quit':
  if child.poll()is None:
   d=observe('Shutdown');end=time.monotonic()+20
   while not d['stopped']:
    assert time.monotonic()<end;time.sleep(.05);d=observe()
   child.wait(timeout=10)
  print(json.dumps({'owned_child_exit':child.returncode}),flush=True);break
 else:raise ValueError(command)
