import argparse,subprocess,json,hashlib
from pathlib import Path
p=argparse.ArgumentParser();p.add_argument('workspace',type=Path);p.add_argument('output',type=Path);a=p.parse_args()
def git(*args):return subprocess.check_output(['git','-C',str(a.workspace),*args],stderr=subprocess.STDOUT).decode().strip()
a.output.mkdir(parents=True,exist_ok=True)
before={'head':git('rev-parse','HEAD'),'base':git('rev-parse','main'),'branch':git('symbolic-ref','--short','HEAD'),'status':git('status','--porcelain=v1')}
assert before['branch'].startswith('workspace/m2-19-'),before
(a.workspace/'earlier-commit.txt').write_text('M2_19_EARLIER_BRANCH_COMMIT\n')
git('add','earlier-commit.txt');git('commit','-qm','Earlier workspace code for whole comparison')
(a.workspace/'proof.txt').write_text('M2_19_STAGED_CONTENT\n')
git('add','proof.txt')
(a.workspace/'proof.txt').write_text('M2_19_UNSTAGED_CONTENT\n')
(a.workspace/'untracked-native.txt').write_text('M2_19_UNTRACKED_CONTENT\n')
expected={'before':before,'head':git('rev-parse','HEAD'),'base':git('rev-parse','main'),'status':git('status','--porcelain=v1'),'index_proof':git('show',':proof.txt'),'working_proof':(a.workspace/'proof.txt').read_text(),'new_file':(a.workspace/'untracked-native.txt').read_text(),'earlier_commit_file':git('show','HEAD:earlier-commit.txt'),'working_staged_patch':git('diff','--cached','--','proof.txt'),'working_unstaged_patch':git('diff','--','proof.txt'),'whole_expected_patch':git('diff','main','--','proof.txt','earlier-commit.txt')}
(a.output/'expected-c4.json').write_text(json.dumps(expected,indent=2)+'\n')
print(json.dumps(expected,indent=2))
