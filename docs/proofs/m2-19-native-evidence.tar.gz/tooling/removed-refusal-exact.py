import sys,json
from pathlib import Path
R=Path('/Users/christopherbengtsson/.rat19-proof-a56eee5');sys.path.insert(0,str(R/'tooling'));import operate as o
steps=[o.text('B'),o.text('/'),o.text('7164c02d-e496-40d1-b0d4-e21ec1a92462'),o.key('0d',1),{'expect_visible':'Enter reads','timeout':8},{'expect_visible':'be6e219c-edbb-4bb2-8ca7-8f79f72879e7','timeout':5},o.text('v',1),{'capture':'exact-original-removed-checkout-refusal'}]
a=o.drive('removed-original-exact-native-refusal',steps,ending='loss',dashboard_color=True)
(R/'removed-exact-native-refusal.json').write_text(json.dumps(a,indent=2))
