import socket,struct,subprocess,json,os,signal,time,ctypes
from pathlib import Path
R=Path('/Users/christopherbengtsson/.rat19-proof-a56eee5');B=R/'bin/agent-terminal';S=R/'state'
s=socket.socket(socket.AF_UNIX);s.connect(str(S/'supervisor.sock'));pid=struct.unpack('i',s.getsockopt(0,2,4))[0];f=s.makefile('rb');g=json.loads(f.readline());assert not g['control_denied'];s.sendall(b'"Screen"\n');d=json.loads(f.readline());assert not any(x['lifecycle']=='Running'for x in d['sessions'])
lib=ctypes.CDLL('/usr/lib/libproc.dylib');buf=ctypes.create_string_buffer(4096);assert lib.proc_pidpath(pid,buf,4096)>0;assert Path(os.fsdecode(buf.value)).resolve()==B.resolve()
ps=subprocess.check_output(['ps','-p',str(pid),'-o','pid=,ppid=,lstart=,command='],text=True).strip();assert str(B)+' --supervisor '+str(S)in ps
cwd=subprocess.check_output(['/usr/sbin/lsof','-a','-p',str(pid),'-d','cwd','-Fn'],text=True);assert '\nn'+str(R)+'\n'in '\n'+cwd
# Kept authenticated connection open; same fresh peer still alive at boundary.
assert subprocess.check_output(['ps','-p',str(pid),'-o','pid=,ppid=,lstart=,command='],text=True).strip()==ps
os.kill(pid,signal.SIGTERM);f.close();s.close();time.sleep(1)
remaining=subprocess.run(['ps','-p',str(pid),'-o','pid=,ppid=,lstart=,command='],capture_output=True,text=True).stdout
(R/'cold-current-peer-owner-cleanup.json').write_text(json.dumps({'authority':'current authenticated Unix LOCAL_PEERPID, exact canonical executable/argv/cwd/current start identity; no saved PID authority','peer_pid':pid,'before_ps':ps,'before_observation':d,'signal':'SIGTERM','remaining_ps':remaining,'socket_exists':(S/'supervisor.sock').exists()},indent=2))
print('fresh peer owner termination',pid,'remaining',repr(remaining))
