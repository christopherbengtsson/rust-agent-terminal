import sys,json,time
from pathlib import Path
R=Path('/Users/christopherbengtsson/.rat19-proof-a56eee5');sys.path.insert(0,str(R/'tooling'));import operate as o
before=o.observe()
# First unavailable case captured real refusal before extra-Esc harness exit; retained separately.
b=o.drive('removed-checkout-selected-native-refusal',o.select('amber-claude',True)+[o.text('w'),o.text('B',1),o.text('j'),o.text('v',1),{'capture':'removed-checkout-resume-refusal'},o.key('1b')],ending='detach',dashboard_color=True)
(R/'removed-checkout-refusal.json').write_text(json.dumps(b,indent=2))
# Explicitly restore one intact original Claude owner for dashboard-loss/crash; no all-session restart.
c=o.drive('explicit-one-original-claude-for-lifecycle',o.select('cobalt-claude')+[o.text('w'),o.text('B',1),o.text('v',4),{'capture':'one-resumed-for-lifecycle'}],ending='detach',dashboard_color=True)
assert c['observation']['lifecycle']=='Running',c['observation']
d=o.drive('actual-dashboard-loss-native-survives',o.select('cobalt-claude')+[o.key('0d'),{'capture':'before-dashboard-loss'}],ending='loss',dashboard_color=True)
e=o.drive('same-native-reconnect-after-dashboard-loss',o.select('cobalt-claude')+[o.key('0d'),{'capture':'same-native-after-reconnect'}],ending='detach',dashboard_color=True)
for z in [d,e]:
 assert z['observation']['session_identity']==c['observation']['session_identity']
 assert z['observation']['native_conversation']==c['observation']['native_conversation']
 assert z['observation']['execution']==c['observation']['execution']
(R/'dashboard-loss-reconnect.json').write_text(json.dumps({'explicit_resume':c,'loss':d,'reconnect':e,'before_crash':o.observe()},indent=2))
