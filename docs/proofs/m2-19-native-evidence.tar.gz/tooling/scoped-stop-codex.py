import sys,json,time,subprocess,hashlib
from pathlib import Path
sys.path.insert(0,'/Users/christopherbengtsson/.rat19-proof-a56eee5/tooling');import operate
before=operate.observe();target=next(r['target']for r in before['sessions']if bytes(r.get('checkout')or[]).decode()==str(operate.ROOT/'violet-codex'))
steps=operate.select('violet-codex')+[operate.key('0d'),operate.key('0d',1),{'resize':[18,60],'wait':1,'capture':'native-active-60x18'},{'resize':[40,160],'wait':1,'capture':'native-active-160x40'},operate.key('1d',.3),{'resize':[18,60],'wait':.7,'capture':'dashboard-focus-60x18'},{'resize':[40,160],'wait':.7,'capture':'dashboard-focus-160x40'},operate.key('0d',.5),{'capture':'reattached-same-native','wait':.2}]
active_result=operate.drive('codex-heartbeat-resize-focus-reattach',steps,dashboard_color=True);active=active_result['observation']
assert active['native_conversation']=='01a1b3e0-24f2-7a41-9c1f-bfa0120d50a6' and active['session_identity']['session']=='f34cd3fb-079e-4607-8ae5-61570baf65ad'
hb=operate.ROOT/'violet-codex/native-heartbeat.jsonl';deadline=time.monotonic()+5
while not hb.exists()and time.monotonic()<deadline:time.sleep(.02)
assert hb.exists(),'approved foreground child did not start'
lines_before=hb.read_text().splitlines();child=json.loads(lines_before[-1]);native=active['execution']['pid']
raw=subprocess.run(['ps','-axo','pid=,ppid=,pgid=,comm='],capture_output=True,text=True).stdout
processes={}
for line in raw.splitlines():
 fields=line.split(None,3)
 if len(fields)==4:processes[int(fields[0])]={'pid':int(fields[0]),'ppid':int(fields[1]),'pgid':int(fields[2]),'comm':fields[3]}
owned={native}
while True:
 new={pid for pid,row in processes.items()if row['ppid']in owned}
 if new.issubset(owned):break
 owned|=new
assert child['pid']in owned,(child,[processes[p]for p in owned])
ps_before=subprocess.run(['ps','-p',','.join(map(str,sorted(owned))),'-o','pid,ppid,pgid,lstart,command'],capture_output=True,text=True).stdout
stopped=operate.drive('stop-only-codex-foreground-workspace',operate.select('violet-codex')+[operate.text('s',3),{'capture':'codex-scoped-stop-result','wait':.3}])['observation']
deadline=time.monotonic()+8
while stopped['metadata_pending']or stopped['capture_pending_bytes']:
 assert time.monotonic()<deadline,stopped
 time.sleep(.03);stopped=operate.observe()
assert stopped['lifecycle']=='Stopped',stopped
others_before={r['target']:(r['session'],r['lifecycle'],r['checkout'])for r in before['sessions']if r['lifecycle']=='Running'and r['target']!=target};others_after={r['target']:(r['session'],r['lifecycle'],r['checkout'])for r in stopped['sessions']if r['lifecycle']=='Running'}
assert len(others_before)==5 and others_before==others_after
last=hb.read_text();time.sleep(.5);assert hb.read_text()==last,'heartbeat continued after confirmed Stop'
ps_after=subprocess.run(['ps','-p',','.join(map(str,sorted(owned))),'-o','pid,ppid,pgid,lstart,command'],capture_output=True,text=True).stdout
assert not ps_after.splitlines()[1:],ps_after
result={'before':before,'active':active,'stopped':stopped,'heartbeat_before_lines':len(lines_before),'heartbeat_after_lines':len(last.splitlines()),'last_heartbeat':json.loads(last.splitlines()[-1]),'stable_after_stop':True,'other_five_unchanged_running':True,'owned_native_and_descendant_count':len(owned),'owned_processes_before':[processes[p]for p in sorted(owned)],'ps_before':ps_before,'ps_after':ps_after,'source':active_result['before'],'runner_sha256':active_result['runner_sha256'],'terminal_env':active_result['terminal_env'],'script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest()}
(operate.ROOT/'codex-scoped-stop.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({k:v for k,v in result.items()if k not in['before','active','stopped','owned_processes_before','ps_before']},indent=2))
