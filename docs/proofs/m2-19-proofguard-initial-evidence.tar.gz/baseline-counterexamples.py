"""Pure evaluation of the original guards: no processes/controllers are inspected."""
import ast
import json
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import patch
from test_guards import load, native, recovery

root=Path(__file__).parent
old_native=load('old_native',root/'baseline/m2-19-native.py')
old_recovery=load('old_recovery',root/'baseline/m2-19-recovery.py')
args=SimpleNamespace(source=Path('/source'),binary=Path('/product'),pin=None)
with patch.object(old_native,'run',side_effect=lambda *args:' M src/file.rs' if 'status' in args else 'commit'),patch.object(old_native,'sha',return_value='hash'):
    old_dirty=old_native.boundary(args)

# Evaluate the literal old editor condition from its AST, not a paraphrase.
module=ast.parse((root/'baseline/m2-19-native.py').read_text())
condition=next(node.test for node in ast.walk(module) if isinstance(node,ast.If) and 'expected[\'executable\'] in command' in ast.unparse(node.test))
editor_eval=compile(ast.Expression(condition),'<original editor predicate>','eval')
expected={'executable':'/usr/bin/vim','operand':'/proof/proof.txt'}
old_editor=eval(editor_eval,{},dict(group=100,child=SimpleNamespace(pid=101),expected=expected,command='/bin/sh -c echo /usr/bin/vim /proof/proof.txt'))
new_editor=native.editor_identity_matches({'executable_bytes':list(b'/bin/sh'),'kernel_executable_bytes':list(b'/bin/sh'),'argv_bytes':[list(v)for v in [b'/bin/sh',b'-c',b'echo /usr/bin/vim /proof/proof.txt']]},expected)

workspace='11111111-1111-4111-8111-111111111111';request='22222222-2222-4222-8222-222222222222';ref=f'refs/rat/archive/{workspace}/{request}'
def git_fixture(argv,timeout=10):
    if 'for-each-ref' in argv:return f'{ref} abcdef\n'.encode()
    if '-t' in argv:return b'tree\n'
    if '-e' in argv:return b''
    raise AssertionError(argv)
with patch.object(old_recovery,'output',side_effect=git_fixture):
    old_ref=old_recovery.code_snapshot({'workspaces':[],'projects':[{'id':'p','common_dir':list(b'/fake')}]})

# Same literal old selected-context expression, with another valid old segment.
module=ast.parse((root/'baseline/m2-19-recovery.py').read_text())
assignment=next(node for node in ast.walk(module) if isinstance(node,ast.Assign) and any("checks['public_selected_native_id_preserved']"==ast.unparse(target)for target in node.targets))
old_selected=eval(compile(ast.Expression(assignment.value),'<original selected context predicate>','eval'),{},dict(selected='B',previous_selected='A',before={'A':{'native_conversation':'native-A'},'B':{'native_conversation':'native-B'}},observation={'native_conversation':'native-B'}))
new_selected=recovery.selected_context_preserved({'available':True,'observation':{'registry':{'selected':'workspace-A'},'session_identity':{'session':'A'},'native_conversation':'native-A'}},{'registry':{'selected':'workspace-B'},'session_identity':{'session':'B'},'native_conversation':'native-B'},{'A':{'native_conversation':'native-A'},'B':{'native_conversation':'native-B'}})
result={'original_dirty_boundary_wrongly_accepted':bool(old_dirty['dirty']),'original_editor_shell_mention_wrongly_accepted':old_editor,'new_editor_shell_mention_accepted':new_editor,'original_primary_archive_tree_wrongly_accepted':old_ref['recovery_refs'][0]['object_type']=='tree','original_changed_selected_context_wrongly_accepted':old_selected,'new_changed_selected_context_accepted':new_selected,'scope':'pure original-source AST/function fixtures; no live process/controller/native/runtime calls'}
assert all(result[key]is True for key in ['original_dirty_boundary_wrongly_accepted','original_editor_shell_mention_wrongly_accepted','original_primary_archive_tree_wrongly_accepted','original_changed_selected_context_wrongly_accepted'])
assert new_editor is False and new_selected is False
(root/'baseline-counterexamples.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
