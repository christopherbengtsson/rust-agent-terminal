import os,pty,fcntl,termios,struct,subprocess,time,socket,json,select
from pathlib import Path
root=Path('/private/tmp/rat-ticket-18/docs/proofs');binary='/private/tmp/rat-ticket-18/target/debug/agent-terminal';results=[]
for kind,mode in [('claude','stop'),('claude','quit'),('codex','quit')]:
 name='18-fixed1-'+kind+'-'+mode;old=json.loads((root/(name+'.json')).read_text());state=old['state'];repo=old['repo'];master,slave=pty.openpty();fcntl.ioctl(slave,termios.TIOCSWINSZ,struct.pack('HHHH',40,160,0,0));p=subprocess.Popen([binary,repo,'--state-dir',state],stdin=slave,stdout=slave,stderr=slave,start_new_session=True)
 def drain(sec):
  end=time.monotonic()+sec
  while time.monotonic()<end:
   if select.select([master],[],[],.03)[0]:
    try:os.read(master,65536)
    except OSError:break
 drain(1.5);os.write(master,b'\x1dd');drain(1);p.wait(timeout=5);os.close(slave)
 end=time.monotonic()+8
 while time.monotonic()<end:
  s=socket.socket(socket.AF_UNIX);s.settimeout(3);s.connect(state+'/supervisor.sock');f=s.makefile('rb');d=json.loads(f.readline(4194305))
  if not d['control_denied']:break
  s.close();time.sleep(.1)
 def request(value):s.sendall(json.dumps(value).encode()+b'\n');return json.loads(f.readline(4194305))
 assert d['lifecycle']=='Stopped' and d['execution'] is None and d['written_bytes']==d['durable_bytes'] and not d['metadata_pending'] and d['capture_pending_bytes']==0
 hb=Path(repo+'/heartbeat.jsonl');before=hb.read_text();time.sleep(1);assert before==hb.read_text();pid=old['heartbeat_before']['pid'];ps=subprocess.run(['ps','-p',str(pid),'-o','pid,lstart,command'],capture_output=True,text=True);assert ps.returncode!=0
 history=request({'History':{'index':0,'offset':0}});r=request('Shutdown');initial=r;end=time.monotonic()+8
 while not r['stopped'] and time.monotonic()<end:time.sleep(.05);r=request('Screen')
 assert r['stopped'];s.close();results.append({'source':old['source'],'original_receipt':name+'.json','native_workflow_passed':True,'collector_initial_failure':old['error'],'verification_tail':'Fresh read-only dashboard reconnect, stable old heartbeat/PID absence, restored current written==durable (owner accepted counter resets), readable History, provisional Shutdown polled to confirmed','observation':d,'history':history,'initial_shutdown':initial,'confirmed_shutdown':r,'heartbeat_absent_ps':ps.stdout})
(root/'18-fixed1-completed-tails.json').write_text(json.dumps(results,ensure_ascii=False,indent=2));print(json.dumps([{'receipt':r['original_receipt'],'native_workflow_passed':r['native_workflow_passed'],'durable':r['observation']['durable_bytes'],'shutdown':r['confirmed_shutdown']['stopped']} for r in results]))
