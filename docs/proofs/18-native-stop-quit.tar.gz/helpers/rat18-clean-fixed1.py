import socket,json,time,subprocess
from pathlib import Path
state='/private/tmp/rat18-fixed1-codex-stop-state';s=socket.socket(socket.AF_UNIX);s.settimeout(3);s.connect(state+'/supervisor.sock');f=s.makefile('rb');d=json.loads(f.readline(4194305));assert not d['control_denied'] and d['adopted']=='/private/tmp/rat18-fixed1-codex-stop-checkout'
def req(v):s.sendall(json.dumps(v).encode()+b'\n');return json.loads(f.readline(4194305))
r=req('Shutdown');first=r;end=time.monotonic()+8
while not r['stopped'] and time.monotonic()<end:time.sleep(.05);r=req('Screen')
assert r['stopped'];s.close();time.sleep(.2);ps=subprocess.run(['ps','-p','13493,13655','-o','pid,lstart,command'],capture_output=True,text=True);assert ps.returncode!=0
Path('/private/tmp/rat-ticket-18/docs/proofs/18-fixed1-aborted-collector-cleanup.json').write_text(json.dumps({'reason':'collector stopped before native Stop action because live tracker ps appeared as a direct child; does not count as a dashboard Stop proof','initial':d,'shutdown_initial':first,'shutdown_confirmed':r,'known_owner_native_absence':ps.stdout},indent=2));print({'stopped':r['stopped'],'known_owner_and_native_absent':ps.returncode!=0})
