import os,sys,pty,fcntl,termios,struct,subprocess,time,socket,json,select,signal,hashlib,uuid
from pathlib import Path
kind,mode=sys.argv[1:3];binary=os.environ['RAT18_BINARY'];checkpoint=os.environ['RAT18_REVISION'];tag=os.environ.get('RAT18_TAG','review1');base='/private/tmp/rat18-'+tag+'-'+kind+'-'+mode;repo=base+'-checkout';state=base+'-state';out=Path('/private/tmp/rat-ticket-18/docs/proofs');assert mode=='quit';assert not os.path.exists(state) and not os.path.exists(repo)
subprocess.run(['git','init','-b','main',repo],check=True,capture_output=True)
heartbeat='''import os,time,json\nfrom pathlib import Path\nfor n in range(240):\n with Path("heartbeat.jsonl").open("a") as f:\n  f.write(json.dumps({"pid":os.getpid(),"ppid":os.getppid(),"pgid":os.getpgrp(),"n":n,"time":time.time()})+"\\n");f.flush()\n time.sleep(.5)\n'''
Path(repo+'/proof-heartbeat.py').write_text(heartbeat)
proof={'driver_sha256_before_launch':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'source':checkpoint,'binary':binary,'binary_sha256_before_launch':hashlib.sha256(Path(binary).read_bytes()).hexdigest(),'kind':kind,'mode':mode,'repo':repo,'state':state,'snapshots':[]}
canonical={'claude':'/Users/christopherbengtsson/.local/share/claude/versions/2.1.318','codex':'/Users/christopherbengtsson/.codex/packages/standalone/releases/0.167.0-aarch64-apple-darwin/bin/codex'}[kind]
assert os.path.realpath('/private/tmp/rat18-tools/'+kind)==canonical
proof['native_canonical']=canonical;proof['native_sha256_before_launch']=hashlib.sha256(Path(canonical).read_bytes()).hexdigest()
master,slave=pty.openpty();original=termios.tcgetattr(slave);fcntl.ioctl(slave,termios.TIOCSWINSZ,struct.pack('HHHH',40,160,0,0));env=dict(os.environ,PATH='/private/tmp/rat18-tools:'+os.environ['PATH']);raw=bytearray();p=None
name='18-'+tag+'-'+kind+'-'+mode

def wait(t=.3):
 end=time.monotonic()+t
 while time.monotonic()<end:
  if select.select([master],[],[],.03)[0]:
   try:
    b=os.read(master,65536)
    if not b:break
    raw.extend(b);assert len(raw)<=8*1024*1024
   except OSError:break

def send(b):os.write(master,b);wait()
def screen(label='latest'):
 path=out/(name+'-'+label+'.raw');path.write_bytes(raw);subprocess.run(['/private/tmp/rat18-parse',str(path),'40','160'],check=True);return json.loads(path.with_suffix('.cells.json').read_text())['text']
def until(pred,seconds=40):
 end=time.monotonic()+seconds
 while time.monotonic()<end:
  wait(.2);text=screen()
  if pred(text):return text
 raise RuntimeError('timeout: '+screen())
def launch_dashboard():
 global p,raw
 raw=bytearray();p=subprocess.Popen([binary,repo,'--state-dir',state],stdin=slave,stdout=slave,stderr=slave,start_new_session=True,env=env);wait(1.2)
def native_processes():
 lines=subprocess.check_output(['ps','-Ao','pid,ppid,pgid,command']).decode().splitlines();rows=[]
 for line in lines[1:]:
  part=line.strip().split(None,3)
  if len(part)==4:rows.append((int(part[0]),int(part[1]),int(part[2]),part[3]))
 owners=[r for r in rows if r[3]==binary+' --supervisor '+state];assert len(owners)==1,owners
 children=[r for r in rows if r[1]==owners[0][0] and ('/claude/versions/2.1.318' in r[3] or r[3].startswith('codex --no-daemon'))];assert len(children)==1,children
 return owners[0],children[0]
def connect():
 end=time.monotonic()+8
 while time.monotonic()<end:
  s=socket.socket(socket.AF_UNIX);s.settimeout(3)
  try:
   s.connect(state+'/supervisor.sock');f=s.makefile('rb');d=json.loads(f.readline(4194305))
   if not d.get('control_denied'):return s,f,d
  except (OSError,ValueError):pass
  s.close();time.sleep(.1)
 raise RuntimeError('no controller')
def request(s,f,value):s.sendall(json.dumps(value).encode()+b'\n');return json.loads(f.readline(4194305))
def identity(value):
 typed=value['session_identity'];assert isinstance(typed,dict)
 for key in ['task','session','request']:assert str(uuid.UUID(typed[key]))==typed[key]
 assert value['identity']=='task='+typed['task']+' session='+typed['session']+' request='+typed['request']
 return typed

def snapshot(label):
 screen(label);proof['snapshots'].append(label)

try:
 launch_dashboard();before=subprocess.check_output(['git','-C',repo,'status','--porcelain']);until(lambda t:'Discovery complete' in t);assert subprocess.check_output(['git','-C',repo,'status','--porcelain'])==before;proof['discovery_read_only']=True
 send(b'a');send(b'c' if kind=='claude' else b'x')
 if kind=='claude':
  until(lambda t:'Accessing workspace' in t);send(b'\x1b[B');send(b'\r')
  until(lambda t:any(mode in t for mode in ['auto mode on','manual mode on','plan mode on']))
  for _ in range(3):
   if 'manual mode on' in screen():break
   send(b'\x1b[Z')
  assert 'manual mode on' in screen()

 else:
  until(lambda t:'Trust this folder?' in t);send(b'\r');until(lambda t:'Hooks need review' in t);snapshot('hooks');send(b'\x1b[B');send(b'\r');until(lambda t:'Ask Codex to do anything' in t)
 prompt='Run exactly python3 proof-heartbeat.py in the foreground in this temporary checkout. This is an authorized harmless bounded heartbeat to test dashboard '+mode+'. Do not run other commands or change files.'
 if kind=='codex':prompt+=' Use require_escalated permission and a justification so I can approve it once.'
 proof['prompt']=prompt;send(b'\x1b[200~'+prompt.encode()+b'\x1b[201~');send(b'\r')
 until(lambda t:('Do you want to proceed?' in t if kind=='claude' else 'Would you like to run the following command?' in t));snapshot('approval');send(b'\r')
 hb=Path(repo+'/heartbeat.jsonl');deadline=time.monotonic()+25
 while time.monotonic()<deadline:
  wait(.1)
  if hb.exists() and len(hb.read_text().splitlines())>=4:break
 else:raise RuntimeError('no heartbeat')
 owner,child=native_processes();rows=hb.read_text().splitlines();last=json.loads(rows[-1]);ids=list(dict.fromkeys([owner[0],child[0],last['pid'],last['ppid'],last['pgid']]))
 proof.update(owner_pid=owner[0],native_pid=child[0],heartbeat_before=last,before_count=len(rows),before_ps=subprocess.check_output(['ps','-p',','.join(map(str,ids)),'-o','pid,ppid,pgid,lstart,command']).decode())
 snapshot('running');send(b'\x1d');send(b'd');wait();p.wait(timeout=8)
 proof['before_q_detach_terminal_restored']=termios.tcgetattr(slave)==original
 s,f,before=connect();proof['before_quit_observation']=before;typed=identity(before)
 assert before['lifecycle']=='Running' and before['execution']['pid']==child[0]
 assert str(uuid.UUID(before['native_conversation']))==before['native_conversation']
 assert any(event.startswith('PermissionRequest:') for event in before['status']['recent'])
 s.close();f.close()
 deadline=time.monotonic()+8
 while True:
  launch_dashboard();current=screen()
  if 'Another dashboard controls this supervisor' not in current:break
  send(b'd');p.wait(timeout=3);assert time.monotonic()<deadline
 until(lambda t:'Process: Running' in t)
 snapshot('reopened-before-quit');send(b'\x1d');start=time.monotonic();send(b'q');wait(3)

 if mode=='quit':
  deadline=time.monotonic()+8
  while p.poll() is None and time.monotonic()<deadline:wait(.1)
  assert p.poll()==0,('quit did not exit',screen())
  proof['quit_terminal_restored']=termios.tcgetattr(slave)==original
  snapshot('quit');launch_dashboard();until(lambda t:'Process: Stopped' in t or 'Process: Exited' in t)
 else:until(lambda t:'Process: Stopped' in t,10)
 proof['visible_stop_seconds']=time.monotonic()-start
 snapshot('stopped');after=hb.read_text().splitlines();wait(1);stable=len(after)==len(hb.read_text().splitlines());ps=subprocess.run(['ps','-p',','.join(map(str,ids)),'-o','pid,ppid,pgid,lstart,command'],capture_output=True,text=True).stdout
 proof.update(after_count=len(after),heartbeat_stable=stable,after_ps=ps)
 # A stopped record alone never establishes native command cleanup.
 alive=subprocess.run(['ps','-p',str(last['pid']),'-o','command='],capture_output=True,text=True)
 proof['heartbeat_pid_absent']=alive.returncode!=0;assert stable and alive.returncode!=0,('native heartbeat survived',proof)
 native_after=subprocess.run(['ps','-p',str(child[0]),'-o','command='],capture_output=True,text=True);proof['native_pid_absent']=native_after.returncode!=0;assert native_after.returncode!=0
 send(b'\x1d');send(b'd');wait();p.wait(timeout=8);proof['detach_terminal_restored']=termios.tcgetattr(slave)==original
 s,f,d=connect();proof['observation']=d;assert d['lifecycle']=='Stopped' and d['execution'] is None
 assert identity(d)==typed and d['identity']==before['identity'] and d['native_conversation']==before['native_conversation']
 end=time.monotonic()+8
 while time.monotonic()<end and (d['metadata_pending'] or d['capture_pending_bytes']):d=request(s,f,'Screen');time.sleep(.05)
 proof['final_observation']=d;assert not d['metadata_pending'] and d['capture_pending_bytes']==0 and d['written_bytes']==d['durable_bytes'] and (mode=='quit' or d['accepted_bytes']==d['durable_bytes'])
 history=request(s,f,{'History':{'index':0,'offset':0}});end=time.monotonic()+5
 while not isinstance(history.get('history'),dict) and time.monotonic()<end:time.sleep(.05);history=request(s,f,'Screen')
 assert history['history']['text'] and typed['session'] in history['history']['identity']
 proof['readable_history']=history

 r=request(s,f,'Shutdown');proof['shutdown_initial']=r;end=time.monotonic()+8
 while not r['stopped'] and time.monotonic()<end:time.sleep(.05);r=request(s,f,'Screen')
 proof['shutdown']=r;assert r['stopped'];s.close();proof['passed']=True
except BaseException as error:
 proof['passed']=False;proof['error']=repr(error)
 if 's' in globals():
  try:s.close();f.close()
  except BaseException:pass
 if p is not None and p.poll() is None:
  try:snapshot('failure');send(b'\x1d');send(b'd');wait();p.wait(timeout=3)
  except BaseException:pass
 try:
  cs,cf,cd=connect();cr=request(cs,cf,'Shutdown');end=time.monotonic()+8
  while not cr['stopped'] and time.monotonic()<end:time.sleep(.05);cr=request(cs,cf,'Screen')
  proof['cleanup_on_failure']={'stopped':cr['stopped'],'identity':cr['identity'],'error':cr['error']};cs.close();cf.close()
 except BaseException as cleanup_error:proof['cleanup_on_failure']={'error':repr(cleanup_error)}
finally:
 (out/(name+'.json')).write_text(json.dumps(proof,ensure_ascii=False,indent=2));os.close(slave);print(json.dumps({k:v for k,v in proof.items() if k not in ['observation','final_observation','shutdown','shutdown_initial','before_quit_observation','readable_history','before_ps','after_ps']},ensure_ascii=False))
if not proof['passed']:sys.exit(1)
