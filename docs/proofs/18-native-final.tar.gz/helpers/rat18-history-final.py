import os,pty,fcntl,termios,struct,subprocess,time,socket,json,select
from pathlib import Path
root=Path('/private/tmp/rat-ticket-18/docs/proofs');binary='/private/tmp/rat-ticket-18/target/debug/agent-terminal';results=[]
for kind,mode in [('claude','stop'),('claude','quit'),('codex','stop'),('codex','quit')]:
 name='18-final3-'+kind+'-'+mode;old=json.loads((root/(name+'.json')).read_text());assert old['passed'];state=old['state'];repo=old['repo'];master,slave=pty.openpty();fcntl.ioctl(slave,termios.TIOCSWINSZ,struct.pack('HHHH',40,160,0,0));p=subprocess.Popen([binary,repo,'--state-dir',state],stdin=slave,stdout=slave,stderr=slave,start_new_session=True)
 def drain(sec):
  end=time.monotonic()+sec
  while time.monotonic()<end:
   if select.select([master],[],[],.03)[0]:
    try:os.read(master,65536)
    except OSError:break
 drain(1.1);os.write(master,b'\x1dd');drain(.5);p.wait(timeout=5);os.close(slave)
 end=time.monotonic()+8
 while time.monotonic()<end:
  s=socket.socket(socket.AF_UNIX);s.settimeout(3);s.connect(state+'/supervisor.sock');f=s.makefile('rb');d=json.loads(f.readline(4194305))
  if not d['control_denied']:break
  s.close();time.sleep(.1)
 def request(value):s.sendall(json.dumps(value).encode()+b'\n');return json.loads(f.readline(4194305))
 assert d['lifecycle']=='Stopped' and d['execution'] is None and d['identity']==old['final_observation']['identity'] and d['written_bytes']==d['durable_bytes']
 history=request({'History':{'index':0,'offset':0}});end=time.monotonic()+5
 while not isinstance(history.get('history'),dict) and time.monotonic()<end:time.sleep(.05);history=request('Screen')
 assert history['history']['text'];assert old['final_observation']['identity'].split(' session=')[1].split()[0] in history['history']['identity']
 r=request('Shutdown');end=time.monotonic()+8
 while not r['stopped'] and time.monotonic()<end:time.sleep(.05);r=request('Screen')
 assert r['stopped'];s.close();results.append({'source':old['source'],'receipt':name+'.json','identity':d['identity'],'native_conversation':d['native_conversation'],'lifecycle':d['lifecycle'],'execution':d['execution'],'durable_bytes':d['durable_bytes'],'history':history['history'],'shutdown_confirmed':r['stopped']})
(root/'18-final3-independent-history.json').write_text(json.dumps(results,ensure_ascii=False,indent=2));print(json.dumps([{'receipt':r['receipt'],'durable':r['durable_bytes'],'readable_history':bool(r['history']['text']),'shutdown':r['shutdown_confirmed']} for r in results]))
