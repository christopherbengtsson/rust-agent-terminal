import os,sys,json,time,socket,pathlib,tempfile,subprocess,pty,fcntl,termios,struct,select,threading,hashlib,uuid
binary=sys.argv[1];out=pathlib.Path(sys.argv[2]);out.mkdir();base=pathlib.Path(tempfile.mkdtemp(prefix='rat19-resume-',dir='/private/tmp'));repo=base/'checkout';repo.mkdir();state=base/'state';state.mkdir(mode=0o700);sock=state/'supervisor.sock';upstream=state/'upstream.sock';events=[];owned=[]
def record(kind,data):
 events.append({'kind':kind,'at_ns':time.monotonic_ns(),'data':data});(out/'trace.json').write_text(json.dumps(events,indent=2))
def owner():
 p=subprocess.Popen([binary,'--supervisor',str(state)],stdin=subprocess.DEVNULL,stdout=open(out/f'owner-{len(owned)}.log','wb'),stderr=subprocess.STDOUT,start_new_session=True);owned.append(p)
 end=time.monotonic()+8
 while not sock.exists():
  assert p.poll() is None,'owner exited';assert time.monotonic()<end;time.sleep(.02)
 return p
class Control:
 def __init__(self,path):
  self.s=socket.socket(socket.AF_UNIX);self.s.settimeout(5);self.s.connect(str(path));self.f=self.s.makefile('rb');self.state=json.loads(self.f.readline());assert not self.state['control_denied']
 def req(self,q):self.s.sendall(json.dumps(q).encode()+b'\n');self.state=json.loads(self.f.readline());return self.state
 def wait(self,p):
  end=time.monotonic()+8
  while True:
   d=self.req('Screen')
   if p(d):return d
   assert time.monotonic()<end,d;time.sleep(.02)
 def close(self):self.f.close();self.s.close()
def selected(d):return {k:d.get(k) for k in ['control_target','lifecycle','launch_request','launch_result','error','metadata_pending','session_identity','adoption_pending','agent','native_conversation','execution']}
try:
 subprocess.run(['git','init','-b','main',str(repo)],check=True,stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
 first=owner();c=Control(sock);c.req({'Adopt':list(os.fsencode(repo))});c.wait(lambda d:not d['adoption_pending'] and not d['registry_pending']);launch=c.req({'Launch':'m219-original-scripted-request'});c.wait(lambda d:d['lifecycle']=='Running' and 'fixture>' in d.get('screen',''));c.req({'Input':list(b'retained-context-08\r')});c.wait(lambda d:'received: retained-context-08' in d.get('screen',''));c.req({'Input':list(b'exit\r')});c.wait(lambda d:d['lifecycle']=='Exited');record('original-exited',selected(c.state));c.req('Shutdown');c.wait(lambda d:d['stopped']);c.close();first.wait(timeout=5)
 repo.rename(base/'removed-checkout');second=owner();c=Control(sock);c.wait(lambda d:d['removal']['ready'] and d['archive']['status']=='Archive operation settled');record('restored-ready',selected(c.state));c.close();time.sleep(.1)
 sock.rename(upstream);listener=socket.socket(socket.AF_UNIX);listener.bind(str(sock));listener.listen();listener.settimeout(8)
 def proxy():
  client,_=listener.accept();server=socket.socket(socket.AF_UNIX);server.connect(str(upstream))
  def forward(a,b,kind):
   pending=b''
   try:
    while True:
     data=a.recv(65536)
     if not data:break
     b.sendall(data);pending+=data
     while b'\n' in pending:
      line,pending=pending.split(b'\n',1)
      try:value=json.loads(line)
      except Exception:continue
      record(kind,selected(value) if kind=='server' else value)
   except Exception as e:record(kind+'-end',str(e))
   try:b.shutdown(socket.SHUT_WR)
   except Exception:pass
  a=threading.Thread(target=forward,args=(client,server,'client'),daemon=True);b=threading.Thread(target=forward,args=(server,client,'server'),daemon=True);a.start();b.start();a.join();b.join();client.close();server.close()
 thread=threading.Thread(target=proxy,daemon=True);thread.start()
 master,slave=pty.openpty();fcntl.ioctl(slave,termios.TIOCSWINSZ,struct.pack('HHHH',40,160,0,0));env=dict(os.environ,TERM='xterm-256color');dashboard=subprocess.Popen([binary,str(repo),'--state-dir',str(state)],stdin=slave,stdout=slave,stderr=slave,start_new_session=True,env=env);owned.append(dashboard);os.close(slave);raw=bytearray()
 def drain(seconds):
  end=time.monotonic()+seconds
  while time.monotonic()<end:
   if select.select([master],[],[],.02)[0]:
    try:raw.extend(os.read(master,65536))
    except OSError:break
 drain(2);record('v-injected',{});os.write(master,b'v');drain(3);(out/'outer.raw').write_bytes(raw);record('detach-injected',{});os.write(master,b'\x1dd');drain(1);dashboard.wait(timeout=5);os.close(master);thread.join(timeout=5);assert not thread.is_alive();listener.close();sock.unlink();upstream.rename(sock)
 c=Control(sock);record('final-direct',selected(c.state));fresh=str(uuid.uuid4());before_error=c.state.get('error');request={'Session':{'target':c.state['control_target'],'session':c.state['session_identity']['session'],'command':{'Resume':fresh}}};record('fresh-request',request);c.req(request);c.wait(lambda d:not d['metadata_pending'] and 'Native resume unavailable' in (d.get('error') or ''));record('fresh-result',selected(c.state));c.req('Shutdown');c.wait(lambda d:d['stopped']);c.close();second.wait(timeout=5)
 (out/'manifest.json').write_text(json.dumps({'binary':binary,'sha256':hashlib.sha256(open(binary,'rb').read()).hexdigest(),'fixture':str(base),'owner_exits':[p.returncode for p in owned]},indent=2));print(json.dumps({'events':len(events),'output':str(out),'owned_exits':[p.returncode for p in owned]}))
finally:
 for p in reversed(owned):
  if p.poll() is None:p.kill();p.wait()
 (out/'owned-cleanup.json').write_text(json.dumps({'owned_exits':[p.returncode for p in owned]},indent=2))
