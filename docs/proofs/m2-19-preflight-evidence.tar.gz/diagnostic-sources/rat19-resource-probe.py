#!/usr/bin/env python3
import os,sys,time,json,socket,subprocess,hashlib,shutil
from pathlib import Path
binary=Path('/tmp/rat19-baseline-bin/agent-terminal')
kind=sys.argv[1];fault=sys.argv[2]=='index-fault';root=Path(sys.argv[3]);root.mkdir();root=root.resolve();repo=root/'repo';repo.mkdir();state=root/'state';state.mkdir(mode=0o700)
subprocess.run(['git','init','-b','main',str(repo)],check=True,capture_output=True)
subprocess.run(['git','-C',str(repo),'-c','user.name=Proof','-c','user.email=proof@example.invalid','commit','--allow-empty','-m','baseline'],check=True,capture_output=True)
if fault:(state/'proof-storage-index-commit').write_text('error')
sha=hashlib.sha256(binary.read_bytes()).hexdigest(); owner=subprocess.Popen([str(binary),'--supervisor',str(state)],stdout=(root/'owner.log').open('wb'),stderr=subprocess.STDOUT)
s=None;events=[]
def save(): (root/'result.json').write_text(json.dumps({'binary':str(binary),'binary_sha256':sha,'kind':kind,'index_fault':fault,'events':events,'owner_pid':owner.pid,'owner_exit':owner.poll()},indent=2))
try:
 for _ in range(200):
  if (state/'supervisor.sock').exists():break
  time.sleep(.025)
 s=socket.socket(socket.AF_UNIX);s.settimeout(8);s.connect(str(state/'supervisor.sock'));f=s.makefile('rb');d=json.loads(f.readline())
 def req(q):
  s.sendall(json.dumps(q).encode()+b'\n');return json.loads(f.readline())
 req({'Adopt':list(os.fsencode(repo))})
 until=time.monotonic()+8
 while True:
  d=req('Screen')
  if not d.get('adoption_pending') and d.get('adopted')==str(repo) and not d.get('registry_pending'):break
  assert time.monotonic()<until,d
  time.sleep(.02)
 req({'Resize':{'rows':32,'cols':104}})
 req({'Launch':'resource-probe-'+str(time.time_ns())})
 until=time.monotonic()+8
 while True:
  d=req('Screen')
  if 'fixture>' in d.get('screen',''):break
  assert time.monotonic()<until,d
  time.sleep(.02)
 before=d['output_bytes'];start=time.monotonic();req({'Input':list((kind+'\r').encode())});last_log=-1;seen=None;durable_seen=None
 until=start+35
 while time.monotonic()<until:
  d=req('Screen');elapsed=time.monotonic()-start
  marker=('osc13-complete' if kind=='osc13' else 'flood13-complete run=1') in d.get('screen','')
  if marker and seen is None:seen=elapsed
  if marker and d['durable_bytes']==d['output_bytes'] and durable_seen is None:durable_seen=elapsed
  if elapsed-last_log>=.2 or durable_seen is not None:
   ev={k:d.get(k) for k in ['output_bytes','accepted_bytes','written_bytes','durable_bytes','capture_pending_bytes','storage_error','storage_wait_millis','capture_high_water','status']};ev.update({'seconds':elapsed,'marker':marker});events.append(ev);last_log=elapsed;save()
  if durable_seen is not None:break
  time.sleep(.02)
 events.append({'marker_seconds':seen,'durable_seconds':durable_seen,'delta_output_bytes':d['output_bytes']-before,'final_screen':d.get('screen'),'session_identity':d.get('session_identity')});save()
 req('Stop');time.sleep(.1)
 stop_until=time.monotonic()+15
 while True:
  d=req('Screen')
  if d.get('lifecycle') in ('Stopped','Exited') and not d.get('metadata_pending') and d.get('capture_pending_bytes')==0:break
  if time.monotonic()>stop_until:raise RuntimeError('owned fixture stop unsettled')
  time.sleep(.05)
 d=req('Shutdown');stop_until=time.monotonic()+10
 while not d.get('stopped'):
  if time.monotonic()>stop_until:raise RuntimeError('owned shutdown unsettled')
  time.sleep(.05);d=req('Screen')
 owner.wait(timeout=10);save()
except BaseException as e:
 events.append({'error':repr(e)});save();raise
finally:
 if s:s.close()
 if owner.poll() is None:
  owner.kill();owner.wait(timeout=10)
 save()
print(json.dumps(events[-1]))
