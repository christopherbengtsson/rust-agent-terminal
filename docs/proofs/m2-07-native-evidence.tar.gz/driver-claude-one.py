import os,sys,pty,fcntl,termios,struct,subprocess,time,socket,json,select,hashlib,uuid
from pathlib import Path
kind=sys.argv[1]; root=Path('/tmp/rat07-proof'); binary='/tmp/rat-ticket07/target/debug/agent-terminal'; tag=sys.argv[2] if len(sys.argv)>2 else 'one'; base='/private/tmp/rat07-'+kind+'-'+tag; repo=base+'-checkout'; state=base+'-state'; assert not os.path.exists(repo) and not os.path.exists(state)
subprocess.run(['git','init','-b','main',repo],check=True,capture_output=True)
Path(repo+'/proof-heartbeat.py').write_text('import os,time,json\nfrom pathlib import Path\nfor n in range(240):\n with Path("heartbeat.jsonl").open("a") as f:\n  f.write(json.dumps({"pid":os.getpid(),"ppid":os.getppid(),"pgid":os.getpgrp(),"n":n})+"\\n");f.flush()\n time.sleep(.5)\n')
proof={'driver_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'parser_sha256':hashlib.sha256(Path('/private/tmp/rat18-parse').read_bytes()).hexdigest(),'source':subprocess.check_output(['git','-C','/tmp/rat-ticket07','rev-parse','HEAD']).decode().strip(),'binary':binary,'binary_sha256':hashlib.sha256(Path(binary).read_bytes()).hexdigest(),'kind':kind,'repo':repo,'state':state,'snapshots':[]}
canonical=os.path.realpath(subprocess.check_output(['which',kind]).decode().strip());proof['native_binary']=canonical;proof['native_sha256']=hashlib.sha256(Path(canonical).read_bytes()).hexdigest();proof['native_version']=subprocess.check_output([canonical,'--version']).decode().strip()
master,slave=pty.openpty();original=termios.tcgetattr(slave);fcntl.ioctl(slave,termios.TIOCSWINSZ,struct.pack('HHHH',40,160,0,0));raw=bytearray();p=None
name='native-'+kind+'-'+tag
# Only terminal output is retained; no raw input-key stream is recorded.
def wait(t=.3):
 end=time.monotonic()+t
 while time.monotonic()<end:
  if select.select([master],[],[],.03)[0]:
   try:
    b=os.read(master,65536)
    if not b:break
    raw.extend(b);assert len(raw)<=8*1024*1024
   except OSError:break
def send(b):os.write(master,b);wait()
def screen(label='latest'):
 path=root/(name+'-'+label+'.raw');path.write_bytes(raw);subprocess.run(['/private/tmp/rat18-parse',str(path),'40','160'],check=True);return json.loads(path.with_suffix('.cells.json').read_text())['text']
def until(pred,seconds=50):
 end=time.monotonic()+seconds
 while time.monotonic()<end:
  wait(.2);text=screen()
  if pred(text):return text
 raise RuntimeError('timeout: '+screen())
def connect():
 end=time.monotonic()+8
 while time.monotonic()<end:
  s=socket.socket(socket.AF_UNIX);s.settimeout(3)
  try:
   s.connect(state+'/supervisor.sock');f=s.makefile('rb');d=json.loads(f.readline(4194305))
   if not d.get('control_denied'):return s,f,d
  except (OSError,ValueError):pass
  s.close();time.sleep(.1)
 raise RuntimeError('no controller')
def request(s,f,value):s.sendall(json.dumps(value).encode()+b'\n');return json.loads(f.readline(4194305))
def snapshot(label):
 screen(label);proof['snapshots'].append(label)
def launch():
 global p,raw
 raw=bytearray();p=subprocess.Popen([binary,repo,'--state-dir',state],stdin=slave,stdout=slave,stderr=slave,start_new_session=True);wait(1)
try:
 launch();until(lambda t:'Discovery complete' in t);send(b'a');until(lambda t:'Adopted:' in t)
 send(b'C' if kind=='claude' else b'X');until(lambda t:'First prompt' in t)
 prompt='Say exactly PROMPT07-'+kind.upper()+' then ask whether I want to run the bounded heartbeat check. Do not run tools or change files.'
 proof['initial_prompt']=prompt;send(b'\x1b[200~'+prompt.encode()+b'\x1b[201~');snapshot('prompt-editor');send(b'\r')
 if kind=='claude':
  until(lambda t:'Accessing workspace' in t);snapshot('trust');send(b'\x1b[B');send(b'\r')
  # Let the initial prompt run; no synthetic extra coding turn.
 else:
  until(lambda t:'Trust this folder?' in t);snapshot('trust');send(b'\r')
  text=until(lambda t:'Hooks need review' in t or 'PROMPT07-CODEX' in t)
  if 'Hooks need review' in text: snapshot('hooks');send(b'\x1b[B');send(b'\r')
 until(lambda t:('heartbeat check?' in t or 'heartbeat check' in t) and t.count('PROMPT07-'+kind.upper()) >= 2,80);wait(2);snapshot('first-answer')
 send(b'\x1d');send(b'w');snapshot('prompt-derived-name');send(b'w');send(b'd');p.wait(timeout=8)
 s,f,initial=connect();proof['initial_observation']=initial;initial_workspace=initial['registry']['workspaces'][0];assert initial_workspace['name'].startswith('Say exactly PROMPT07-'+kind.upper()),initial_workspace
 initial_identity=initial['identity'];initial_native=initial['native_conversation'];native_pid=initial['execution']['pid'];proof['native_ps']=subprocess.check_output(['ps','-p',str(native_pid),'-o','pid,ppid,pgid,command']).decode();proof['native_cwd']=subprocess.check_output(['lsof','-a','-p',str(native_pid),'-d','cwd','-Fn']).decode();f.close();s.close()
 launch();until(lambda t:'Running' in t);send(b'\r');wait(1)
 if kind=='claude':
  for _ in range(4):
   if 'manual mode on' in screen():break
   send(b'\x1b[Z')
  assert 'manual mode on' in screen(),screen()
 command_prompt='Yes. Run exactly python3 proof-heartbeat.py in the foreground in this temporary checkout. This is an authorized harmless bounded heartbeat for managed native first-prompt qualification. Do not run other commands or change files.'
 if kind=='codex':command_prompt+=' Use require_escalated permission and a justification so I can approve it once.'
 proof['explicit_followup_prompt']=command_prompt;send(b'\x1b[200~'+command_prompt.encode()+b'\x1b[201~');send(b'\r')
 until(lambda t:('Do you want to proceed?' in t if kind=='claude' else 'Would you like to run the following command?' in t),80);snapshot('approval');send(b'\r')
 hb=Path(repo+'/heartbeat.jsonl');end=time.monotonic()+30
 while time.monotonic()<end:
  wait(.15)
  if hb.exists() and len(hb.read_text().splitlines())>=4:break
 else:raise RuntimeError('no heartbeat')
 snapshot('running');proof['heartbeat_before']=json.loads(hb.read_text().splitlines()[-1]);send(b'\x03');wait(1);snapshot('native-interrupt')
 send(b'\x1d');send(b'R');until(lambda t:'Workspace name (local)' in t);send(b'\x15');send(b'Manual '+kind+' workspace');snapshot('rename-editor');send(b'\r');wait(.7);send(b'w');snapshot('renamed-workspaces');send(b'w');send(b'd');p.wait(timeout=8)
 proof['terminal_restored_detach']=termios.tcgetattr(slave)==original
 s,f,current=connect();proof['after_rename']=current;workspace=current['registry']['workspaces'][0];assert workspace['name']=='Manual '+kind+' workspace',workspace
 assert current['native_conversation'];identity=current['identity'];native=current['native_conversation'];assert identity==initial_identity;assert native==initial_native;assert workspace['id']==initial_workspace['id'];assert workspace['path']==initial_workspace['path'];proof['native_pid']=current['execution']['pid']
 assert current['registry']['selected']==workspace['id'];assert current['launch_request'];result=request(s,f,{'QueryLaunch':current['launch_request']});assert result['identity']==identity;assert result['native_conversation']==native;proof['same_request_result']=result
 stop=request(s,f,'Stop');end=time.monotonic()+15
 while time.monotonic()<end:
  if stop['lifecycle']=='Stopped' and not stop['metadata_pending'] and stop['capture_pending_bytes']==0:break
  time.sleep(.1);stop=request(s,f,'Screen')
 else:raise RuntimeError('stop did not settle '+str(stop))
 proof['stopped']=stop;assert stop['execution'] is None
 for pid in [proof['native_pid'],proof['heartbeat_before']['pid']]:
  alive=subprocess.run(['ps','-p',str(pid),'-o','pid='],capture_output=True,text=True).stdout.strip();assert not alive,('owned process still alive',pid)
 proof['owned_processes_gone']=True
 history=request(s,f,{'History':{'index':0,'offset':0}});proof['history']=history.get('history')
 shutdown=request(s,f,'Shutdown');end=time.monotonic()+12
 while not shutdown['stopped'] and time.monotonic()<end:time.sleep(.1);shutdown=request(s,f,'Screen')
 proof['shutdown']=shutdown;assert shutdown['stopped'];f.close();s.close();wait(.3)
 # Restore is observation only: retains names/identity/native ID and never runs a prompt.
 launch();until(lambda t:'Process: Stopped' in t or 'Stopped' in t);snapshot('restored');send(b'd');p.wait(timeout=8)
 s,f,restored=connect();proof['restored']=restored;assert restored['identity']==identity;assert restored['native_conversation']==native;assert restored['registry']['workspaces'][0]['name']==workspace['name'];assert restored['execution'] is None;assert restored['lifecycle']=='Stopped'
 shutdown=request(s,f,'Shutdown');end=time.monotonic()+12
 while not shutdown['stopped'] and time.monotonic()<end:time.sleep(.1);shutdown=request(s,f,'Screen')
 assert shutdown['stopped'];f.close();s.close();proof['passed']=True
except BaseException as e:
 proof['passed']=False;proof['error']=repr(e)
 try:snapshot('failure')
 except:pass
 try:
  if p and p.poll() is None:send(b'\x1d');send(b'd');p.wait(timeout=4)
  s,f,d=connect();proof['failure_cleanup_initial']=d;d=request(s,f,'Stop');end=time.monotonic()+15
  while time.monotonic()<end and d.get('execution') is not None:time.sleep(.1);d=request(s,f,'Screen')
  proof['failure_cleanup']=d;request(s,f,'Shutdown');f.close();s.close()
 except BaseException as cleanup:proof['cleanup_error']=repr(cleanup)
finally:
 (root/(name+'.json')).write_text(json.dumps(proof,ensure_ascii=False,indent=2));os.close(slave);print(json.dumps({'passed':proof['passed'],'error':proof.get('error'),'file':str(root/(name+'.json'))}))
if not proof['passed']:sys.exit(1)
